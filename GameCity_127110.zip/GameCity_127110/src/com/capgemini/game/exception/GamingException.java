package com.capgemini.game.exception;

public class GamingException extends Exception {
	String message;
	public GamingException(String message)
	{
		this.message=message;
	
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

}
