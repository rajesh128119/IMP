package com.capgemini.game.bean;

public class GameBean {
	private String gameName;
	private long gameAmount;
	
	public GameBean() {
		super();
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public long getGameAmount() {
		return gameAmount;
	}
	public void setGameAmount(long gameAmount) {
		this.gameAmount = gameAmount;
	}
	@Override
	public String toString() {
		return "GameBean [gameName=" + gameName + ", gameAmount=" + gameAmount
				+ "]";
	}
	

}
