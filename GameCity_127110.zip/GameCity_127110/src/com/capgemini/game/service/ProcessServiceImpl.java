package com.capgemini.game.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.game.bean.GameBean;
import com.capgemini.game.bean.UsersBean;
import com.capgemini.game.dao.ProcessDao;
import com.capgemini.game.dao.ProcessDaoImpl;
import com.capgemini.game.exception.GamingException;

@Service
@Transactional
public class ProcessServiceImpl implements ProcessService{
	@Autowired
	ProcessDao dao;
	@Override
	public boolean registerUser(UsersBean bean) throws GamingException {
		// TODO Auto-generated method stub
		return dao.registerUser(bean);
	}

	@Override
	public ArrayList<GameBean> showGames() throws GamingException {
		// TODO Auto-generated method stub
		return dao.showGames();
		
	}
	

}
