package com.capgemini.game.service;

import java.util.ArrayList;

import com.capgemini.game.bean.GameBean;
import com.capgemini.game.bean.UsersBean;
import com.capgemini.game.exception.GamingException;

public interface ProcessService {
	public boolean registerUser(UsersBean bean)throws GamingException;//inserting user into database
	public ArrayList<GameBean> showGames()throws GamingException;//getting games list from  database
	

}
