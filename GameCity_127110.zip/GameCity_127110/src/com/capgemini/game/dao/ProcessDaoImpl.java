package com.capgemini.game.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;






import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capgemini.game.bean.GameBean;
import com.capgemini.game.bean.UsersBean;
import com.capgemini.game.exception.GamingException;



@Repository
public class ProcessDaoImpl implements ProcessDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public boolean registerUser(UsersBean bean) throws GamingException {
		// TODO Auto-generated method stub
		boolean flag=true;
		entityManager.persist(bean);
		entityManager.flush();
		return flag;
	
		
	}

	@Override
	public ArrayList<GameBean> showGames() throws GamingException {
		// TODO Auto-generated method stub
		ArrayList<GameBean>list=new ArrayList<GameBean>();
		/*try
		{
			String sql="Select * FROM onlinegames";
			Statement stmt=con.createStatement();
			ResultSet result=stmt.executeQuery(sql);
			while(result.next())
			{
				GameBean bean=new GameBean();
			bean.setGameName(result.getString(1));
			bean.setGameAmount(result.getLong(2));
			
			list.add(bean);
			}
		}
		catch(Exception e)
		{
			throw new GamingException(e.getMessage());
		}
		System.out.println(list);*/
		return list;
		
	}
	

}
