package com.capgemini.game.dao;

import java.util.ArrayList;

import com.capgemini.game.bean.GameBean;
import com.capgemini.game.bean.UsersBean;
import com.capgemini.game.exception.GamingException;

public interface ProcessDao {
	public boolean registerUser(UsersBean bean)throws GamingException;
	public ArrayList<GameBean> showGames()throws GamingException;

}
