package com.capgemini.game.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.game.bean.UsersBean;
import com.capgemini.game.service.ProcessService;


@Controller
public class MyController {
	@Autowired
	UsersBean game;
	@Autowired
	ProcessService service;
	
	
	
	@RequestMapping(value="/showForm")
	public String showForm(Model model)
	{
		
		//LoginBean  - loginBean
	  //model.addAttribute("login", new Login());
	//  model.addAttribute(new Login());//login
		model.addAttribute("login", game);
	  return "GameCity1";//Logical view name
	}
	@RequestMapping(value="/checkLogin")
	public String checkLogin(UsersBean bean)
	
	{
		try
		{service.registerUser(bean);
	  System.out.println("User : "+bean);
		}
		catch(Exception e)
		{
			System.out.println("D");
		}
	  return "Success";	
	


}}
