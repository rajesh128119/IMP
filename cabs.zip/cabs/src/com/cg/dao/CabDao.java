package com.cg.dao;

import com.cg.CabRquestBean;

public interface CabDao {

	public CabRquestBean addCabRequestDetails(CabRquestBean cabRequest);
	
	
}
