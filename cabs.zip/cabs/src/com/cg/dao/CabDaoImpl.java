package com.cg.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.CabRquestBean;

@Repository
public class CabDaoImpl implements CabDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public CabRquestBean addCabRequestDetails(CabRquestBean cabRequest) {
		
		System.out.println(" in dao ");
		// TODO Auto-generated method stub
		cabRequest.setCabNumber("410096");
		cabRequest.setDateOfRequest(LocalDate.now());
		cabRequest.setRequestStatus("accepted");
		entityManager.persist(cabRequest);
		entityManager.flush();
		System.out.println(" dao : " + cabRequest);
		return cabRequest;
	}

	

}
