package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.service.CabService;

@Controller
public class CabController {

	@Autowired
	CabService service;
	
	@Autowired
	CabRquestBean cabs;
	
	@RequestMapping(value="/showForm")
	public String showForm(Model model)
	{
		 model.addAttribute("cabraise",cabs);
			return "cabraise";
	}
	
	@RequestMapping(value="/insertCabs")
	public String insertSuccess(CabRquestBean cabs)
	{
		System.out.println(cabs);
		System.out.println("inserted succesfully!");
		service.addCabRequestDetails(cabs);
		return "index";
	}
}
