package com.cg;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component(value="cabs")
@Entity
@Table(name = "cab_request_new")
public class CabRquestBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="request_id")
	private int requestId;
	@Column(name="customer_name")
	private String customerName;
	@Column(name="phone_number")
	private String phoneNumber;
	@Column(name="date_of_request")
	private LocalDate dateOfRequest;
	@Column(name="request_status")
	private String requestStatus;
	@Column(name="cab_number")
	private String cabNumber;
	@Column(name="address_of_pickup")
	private String addOfPick;
	private String pincode;

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public LocalDate getDateOfRequest() {
		return dateOfRequest;
	}

	public void setDateOfRequest(LocalDate dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getCabNumber() {
		return cabNumber;
	}

	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}

	public String getAddOfPick() {
		return addOfPick;
	}

	public void setAddOfPick(String addOfPick) {
		this.addOfPick = addOfPick;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "CabRquestBean [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", cabNumber=" + cabNumber + ", addOfPick="
				+ addOfPick + ", pincode=" + pincode + "]";
	}

}
