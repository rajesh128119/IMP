package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CabRquestBean;
import com.cg.dao.CabDao;

@Service
@Transactional	
public class CabServiceImpl implements CabService {

	@Autowired
	private CabDao cabDao;
	
	@Override
	public CabRquestBean addCabRequestDetails(CabRquestBean cabRequest) {
		// TODO Auto-generated method stub
		System.out.println(" ins erive ");
		return cabDao.addCabRequestDetails(cabRequest);
	}

	

}
