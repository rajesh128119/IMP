package com.cg.service;

import com.cg.CabRquestBean;

public interface CabService {

	public CabRquestBean addCabRequestDetails(CabRquestBean cabRequest);

	
}
