package com.cg.dao;

import com.cg.bean.Complaint;
import com.cg.exception.ComplaintException;

public interface ComplaintDao {

	
public int addComplaint(Complaint bean) throws ComplaintException;
	
	public Complaint getStatus(int complaintId) throws ComplaintException;
}
