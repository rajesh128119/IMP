package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.Complaint;
import com.cg.exception.ComplaintException;

@Repository
public class ComplaintDaoImpl implements ComplaintDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addComplaint(Complaint bean) throws ComplaintException {
		if(bean.getCategory().equals("Internet Banking")){
			bean.setPriority("High");
			bean.setStatus("Open");
		}
		else if(bean.getCategory().equals("General Banking")){
			bean.setPriority("Medium");
			bean.setStatus("Open");
		}
		else if(bean.getCategory().equals("Others")){
			bean.setPriority("Low");
			bean.setStatus("Open");
		}
		
		entityManager.persist(bean);
		int id = bean.getComplaintId();
		return id;
	}

	@Override
	public Complaint getStatus(int complaintId) throws ComplaintException {
		
		Complaint bean = entityManager.find(Complaint.class,complaintId);
		
		if(bean==null)
		{
			
			throw new ComplaintException(complaintId+"  not found");
		}
		return bean;
	}

	
	
}
