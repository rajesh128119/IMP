package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import oracle.net.aso.l;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Complaint;
import com.cg.exception.ComplaintException;
import com.cg.service.ComplaintService;

@Controller
public class ComplaintController {
	
	@Autowired
	ComplaintService service;
	@Autowired
	Complaint complaint;
	
	ArrayList<String> list= new ArrayList<String>();
	
	@RequestMapping(value="/requestform")
	public String addRequest(@ModelAttribute("complaint")@Valid Complaint complaint,BindingResult result,Model model){
		int complaintId=0;
		if(result.hasErrors())
		{
			model.addAttribute("list", list);
			model.addAttribute("complaint",complaint);
			return "Form";
		}
		else
		{
		
			try 
			{
				complaintId=service.addComplaint(complaint);
				model.addAttribute("complaint",complaint);
				model.addAttribute("id", complaintId);
			} catch (ComplaintException e) {
				
				model.addAttribute("msg",e.getMessage());
			}
		}
		
		return "success";
		
	}
	@RequestMapping(value="/fetch")
	public String goToRetrieveForm(Model model){
		model.addAttribute("complaint",complaint);
		return "status";
	}
	
//	int complaintId=0;
	@RequestMapping(value="/retrieve")
	public String showStatus(int complaintId,Complaint complaint,Model model){
		
		try {
			complaint=service.getStatus(complaintId);
			
			model.addAttribute("complaint",complaint);
		} catch (ComplaintException e) {
			model.addAttribute("msg", e.getMessage());
			return "error";
		}
		if(complaint!=null){
			return "status";
		}else
		{
			model.addAttribute("msg", complaintId+" not found");
			return "error";
		}
		
	}
	
	@RequestMapping(value="/home")
	public String goHome(Model model){
		list.add("Internet Banking");
		list.add("General Banking");
		list.add("Others");
		model.addAttribute("list", list);
		
		model.addAttribute("complaint",complaint);
		return "Form";
		
		
	}
	
	
	

}
