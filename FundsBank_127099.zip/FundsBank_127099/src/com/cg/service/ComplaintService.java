package com.cg.service;

import com.cg.bean.Complaint;
import com.cg.exception.ComplaintException;

public interface ComplaintService {
public int addComplaint(Complaint bean) throws ComplaintException;
	
	public Complaint getStatus(int complaintId) throws ComplaintException;
	
}
