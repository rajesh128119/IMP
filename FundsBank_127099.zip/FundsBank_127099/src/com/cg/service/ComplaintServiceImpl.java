package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Complaint;
import com.cg.dao.ComplaintDao;
import com.cg.exception.ComplaintException;


@Service
@Transactional	
public class ComplaintServiceImpl implements ComplaintService{

	@Autowired
	private ComplaintDao dao;
	
	@Override
	public int addComplaint(Complaint bean) throws ComplaintException {
		 
		return dao.addComplaint(bean);
	}

	@Override
	public Complaint getStatus(int complaintId) throws ComplaintException {
		 
		return dao.getStatus(complaintId);
	}

}
