package com.cg.exception;


public class ComplaintException extends Exception{
	
	private static final long serialVersionUID = 1L;
	String msg;
	
	
	public ComplaintException(String msg) {
		super();
		this.msg = msg;
	}
	@Override
	public String getMessage()
	{
		return msg;
	}

}
