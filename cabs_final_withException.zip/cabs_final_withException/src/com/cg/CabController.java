package com.cg;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.exception.MyException;
import com.cg.service.CabService;

@Controller
public class CabController {

	@Autowired
	CabService service;
	
	@Autowired
	CabRquestBean cabs;

	ArrayList<String> pincodeList;
	@RequestMapping(value="/showForm")
	public String showForm(Model model)
	{
		 model.addAttribute("cabraise",cabs);
		 pincodeList =new ArrayList<String>();
			
			pincodeList.add("411013");
			pincodeList.add("450156");
			pincodeList.add("412012");
			pincodeList.add("800023");
			pincodeList.add("542014");
			pincodeList.add("657845");
			model.addAttribute("list",pincodeList);
		
		 
			return "cabraise";
	}
	
	@RequestMapping(value="/insertCabs")
	public String insertSuccess(@ModelAttribute("cabraise")@Valid CabRquestBean cabs,BindingResult result,Model model) throws MyException
	{
		
		int id = 0;
		
		if(result.hasErrors()){
			System.out.println("error in validation");
			model.addAttribute("list",pincodeList);
			return "cabraise";
		}
		else{
			
			try {
				id = service.addCabRequestDetails(cabs);
			} catch (MyException e) {
				throw new MyException(e.getMessage());
			}
			 model.addAttribute("requestId",id);
			return "success";
		}
		
	}
	
	
	@RequestMapping(value="/fetch")
	public String fetchByID(Model model){
		try{
		model.addAttribute("cabs",cabs);
		}
		catch(DataAccessException dataAccessException)
		{
			model.addAttribute("msg","No record found");
			return "myError";
		}
		return "fetchByID";
		
	}
	
	@RequestMapping(value="/fetchSuccess")
	public String fetchSuccess(Model model,CabRquestBean cabs) throws MyException{
		
		
		 
		try {
			cabs=service.getRequestDetails(cabs.getRequestId());
			model.addAttribute("details",cabs);
			System.out.println("fetched succesfully!");
			return "details";
		} catch (MyException e) {
			model.addAttribute("msg",e.getMessage());
			return "error";
			
		}
		
		
	}
	@RequestMapping(value="/home")
	public String goHome(){
		return "index";
		
	}
}
