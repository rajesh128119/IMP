package com.cg;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component(value="cabs")
@Entity
@Table(name = "cab_request_new")
public class CabRquestBean {

	@Id
	@SequenceGenerator(name="seq1",sequenceName="ID_SEQUENCE",allocationSize=5000)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")

	@Column(name="request_id")
	private int requestId;
	
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="First word should be capital and minimum three words is required")
//	@Size(min=4,max=20,message="Minimum 4 and Maximum 20 characters required")
	@Column(name="customer_name",length=20)
	private String customerName;
	
	@NotEmpty(message="Phone number is mandatory")
	@Pattern(regexp="[0-9]{10}",message="10 digits required")
	@Column(name="phone_number",length=10)
	private String phoneNumber;
	
	@Column(name="date_of_request")
	private Date dateOfRequest;
	
	@Column(name="request_status",length=15)
	private String requestStatus;
	
	@Column(name="cab_number",length=12)
	private String cabNumber;
	
	@NotEmpty(message="Address is mandatory")
	@Column(name="address_of_pickup",length=20)
	private String addOfPick;
	
	@NotEmpty(message="Phone number is mandatory")
	@Pattern(regexp="[0-9]{6}",message="6 digits required")
	@Column(name="pincode",length=6)
	private String pincode;

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Date getDateOfRequest() {
		return dateOfRequest;
	}

	public void setDateOfRequest(Date dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getCabNumber() {
		return cabNumber;
	}

	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}

	public String getAddOfPick() {
		return addOfPick;
	}

	public void setAddOfPick(String addOfPick) {
		this.addOfPick = addOfPick;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "CabRquestBean [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", cabNumber=" + cabNumber + ", addOfPick="
				+ addOfPick + ", pincode=" + pincode + "]";
	}

}
