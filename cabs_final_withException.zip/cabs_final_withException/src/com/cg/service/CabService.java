package com.cg.service;

import com.cg.CabRquestBean;
import com.cg.exception.MyException;

public interface CabService {

	public int addCabRequestDetails(CabRquestBean cabRequest) throws MyException;

	public CabRquestBean getRequestDetails(int requestId) throws MyException;
}
