package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CabRquestBean;
import com.cg.dao.CabDao;
import com.cg.exception.MyException;

@Service
@Transactional	
public class CabServiceImpl implements CabService {

	@Autowired
	private CabDao cabDao;
	@Override
	public int addCabRequestDetails(CabRquestBean cabRequest) throws MyException{
		System.out.println(" in service ");
		return cabDao.addCabRequestDetails(cabRequest);
	}
	@Override
	public CabRquestBean getRequestDetails(int requestId) throws MyException{
		return cabDao.getRequestDetails(requestId);
	}

	

}
