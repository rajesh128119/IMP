package com.cg.dao;

import com.cg.CabRquestBean;
import com.cg.exception.MyException;

public interface CabDao {

	public int addCabRequestDetails(CabRquestBean cabRequest) throws MyException;
	
	public CabRquestBean getRequestDetails(int requestId) throws MyException;
	
}
