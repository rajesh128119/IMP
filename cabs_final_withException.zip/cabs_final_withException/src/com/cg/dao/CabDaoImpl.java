package com.cg.dao;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.CabRquestBean;
import com.cg.exception.MyException;

@Repository
public class CabDaoImpl implements CabDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	CabRquestBean bean;
	
	
	@Override
	public int addCabRequestDetails(CabRquestBean cabRequest) throws MyException{
		
		System.out.println(" in dao add request details");
		// TODO Auto-generated method stub
		if(cabRequest.getPincode().equals("411013")){
			cabRequest.setCabNumber("MH-24 5078");
		}else if(cabRequest.getPincode().equals("450156")){
			cabRequest.setCabNumber("MH-14 8888");
		}
		else if(cabRequest.getPincode().equals("412012")){
			cabRequest.setCabNumber("MH-14 9999");
		}
		else if(cabRequest.getPincode().equals("800023")){
			cabRequest.setCabNumber("MH-28 0007");
		}
		else if(cabRequest.getPincode().equals("542014")){
			cabRequest.setCabNumber("MH-75 2694");
		}else if(cabRequest.getPincode().equals("657845")){
			cabRequest.setCabNumber("MH-18 4545");
		}
		cabRequest.setDateOfRequest(Date.valueOf(LocalDate.now()));
		cabRequest.setRequestStatus("accepted");
		entityManager.persist(cabRequest);
		System.out.println(" dao : " + cabRequest);
		int requestId= cabRequest.getRequestId();
		System.out.println("requestId generated is:"+requestId);
		return requestId;
	}


	@Override
	public CabRquestBean getRequestDetails(int requestId) throws MyException{
		/*CabRquestBean bean= new CabRquestBean();*/
		System.out.println(" in dao get request details");
		
		
		bean=entityManager.find(CabRquestBean.class, requestId);
		if(bean==null)
		{
			throw new MyException("ID not found,please enter a valid id.");
		}
		
		System.out.println("getDetails:"+bean);
		return bean;
	}



}
