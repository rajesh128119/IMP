package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service implements EmployeeService {
	
	Employee e=new Employee();
	

	@Override
	public String getScheme(float salary, String designation) {
		// TODO Auto-generated method stub
		
		if(salary>5000 && salary<20000 && designation.equals("System Associate"))
		{
		return "Scheme C";	
		}
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer"))
		{
		return "Scheme B";	
		}
		else if(salary>=40000 && designation.equals("Manager"))
		{
		return "Scheme A";	
		}
		else if(salary<5000 && designation.equals("Clerk"))
		{
		return "No Scheme";
		}
		else
		{
		return "No Scheme";
		}
		
		
	}
	
	@Override
	public void setDetails(Employee e)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("User Details");
		System.out.println("Enter id:");
		e.setId(sc.nextInt());
		System.out.println("Enter name:");
		e.setName(sc.next());
		System.out.println("Enter salary:");
		e.setSalary(sc.nextFloat());
		System.out.println("Enter designation:");
		e.setDesignation(sc.next());
	}
	
	@Override
	public void getDetails(Employee e)
	{
		//Scanner sc=new Scanner(System.in);
		System.out.println("User Details");
		System.out.println("id:"+e.getId());
		
		System.out.println(" name:"+e.getName());
		
		System.out.println(" salary:"+e.getSalary());
		
		System.out.println(" designation:"+e.getDesignation());
		
		
		
	}
	

}
