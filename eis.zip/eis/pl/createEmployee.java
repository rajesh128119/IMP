package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Service;




public class createEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e=new Employee();
		EmployeeService es=new Service();
		es.setDetails(e);
		
		es.getDetails(e);
		
		System.out.println("Scheme:"+es.getScheme(e.getSalary(),e.getDesignation()));

		

	}

}
