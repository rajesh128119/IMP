--Create a query that will display Student Code, Student Name, Book Code, and
--Book Name for all students whose expected book return date is today.


SQL> select sm.student_code, sm.student_name, bm.book_code, bm.book_name from student_master sm, book_master bm, Book_Transactions bt 
     where sm.student_code= bt.student_code and 
	 bm.book_code=bt.book_code and 
	 Book_expected_return_date =sysdate;

no rows selected