--Display Staff Code, Staff Name, Department Name, and Designation name for
--those who have joined in last 3 months.



SQL> SELECT s.staff_code, s.staff_name, d.dept_name, de.design_name
       from staff_master s, department_master d, designation_master de
       WHERE s.dept_code=d.dept_code AND 
	   s.design_code=de.design_code AND 
	   months_between(sysdate,Hiredate)=3;

no rows selected
