--Display the Manager Name and the total strength of his/her team.


SQL> SELECT count(s.staff_name) as Team, s1.staff_name as Manager
       from staff_master s, staff_master s1
       WHERE s.mgr_code=s1.staff_code
       group by s1.staff_name;

      TEAM MANAGER
---------- --------------------------------------------------
         2 John
         5 Allen
         3 Smith
