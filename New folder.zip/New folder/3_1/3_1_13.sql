--Write a query to display number of people in each Department. Output should
--display Department Code, Department Name and Number of People.


SQL> select d.dept_code, d.dept_name, count(sm.staff_code)
       from staff_master sm, department_master d
       where sm.dept_code= d.dept_code
       group by d.dept_code, d.dept_name;

 DEPT_CODE DEPT_NAME
---------- --------------------------------------------------
COUNT(SM.STAFF_CODE)
--------------------
        30 Electronics
                   3

        20 Electricals
                   4

        10 Computer Science
                   2


 DEPT_CODE DEPT_NAME
---------- --------------------------------------------------
COUNT(SM.STAFF_CODE)
--------------------
        40 Mechanics
                   1
