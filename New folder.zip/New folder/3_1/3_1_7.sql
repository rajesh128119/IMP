Display Author Name, Book Name for those authors who wrote more than one
book.


SQL> select book_pub_author, book_name from book_master 
     where book_pub_author = (select book_pub_author from book_master 
	 group by book_pub_author 
	 having count(book_pub_author)>1);

BOOK_PUB_AUTHOR
--------------------------------------------------
BOOK_NAME
--------------------------------------------------
Yashavant Kanetkar
Let Us C++

Yashavant Kanetkar
Let Us C
