--Display the details of books that have not been returned and expected return date
--was last Monday. Book name should be displayed in proper case.. Hint: You can
--change /add records so that the expected return date suits this problem
--statement


SQL> SELECT *
       from book_transactions
       where book_expected_return_date= next_day(sysdate-7,'monday') and 
	   book_actual_return_date is null;

no rows selected