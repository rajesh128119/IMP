--Create a query that will display Staff Code, Staff Name, Department Name,
--Designation name, Book Code, Book Name, and Issue Date for only those staff
--who have taken any book in last 30 days. . If required, make changes to the table
--to create such a scenario.


SQL> select sm.staff_code, sm.staff_name, dm.Dept_name, dem.Design_name, bm.Book_Code, bm.Book_Name, bt.Book_Issue_date 
     from staff_master sm, Department_Master dm, Designation_Master dem, Book_Master bm, Book_Transactions bt 
	 where sm.staff_code=bt.Staff_code and
	 bm.book_code=bt.book_code and 
	 sysdate-bt.Book_issue_date<30;

no rows selected

SQL> insert into book_transactions values(10000002,1001,100001,'26-APR-17','05-M
AY-17','03-MAY-17');

1 row created.

SQL> select sm.staff_code, sm.staff_name, dm.Dept_name, dem.Design_name, bm.Book_Code, bm.Book_Name, bt.Book_Issue_date 
     from staff_master sm, Department_Master dm, Designation_Master dem, Book_Master bm, Book_Transactions bt 
	 where sm.staff_code=bt.Staff_code and
	 bm.book_code=bt.book_code and 
	 sysdate-bt.Book_issue_date<30;


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
DESIGN_NAME                                         BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME                                          BOOK_ISSU
-------------------------------------------------- ---------
    100001 Arvind
Electricals
Sr.Lecturer                                          10000002
Mastersing VC++                                    26-APR-17