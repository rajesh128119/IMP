--Display Staff Code, Staff Name, Department Name, and his manager’s number and name. 
--Label the columns Staff#, Staff, Mgr#, Manager.


SQL> select s.staff_code as "Staff#",s.staff_name as "Staff", 
     d.dept_name, s.mgr_code as "Mgr#",sm.Staff_Name as "Manager" 
	 from staff_master s, department_master d, staff_master sm 
	 where s.dept_code= d.dept_code and 
	 s.mgr_code= sm.staff_code;

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100007 Smith
Electricals                                            100005
John

    100006 Allen
Electronics                                            100005
John

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100009 Rahul
Electricals                                            100006
Allen

    100008 Raviraj
Mechanics                                              100006

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Allen

    100004 Anil
Electricals                                            100006
Allen

    100003 Mohan

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Computer Science                                       100006
Allen

    100001 Arvind
Electronics                                            100006
Allen


    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100010 Ram
Electronics                                            100007
Smith

    100005 John
Computer Science                                       100007
Smith

    Staff# Staff
---------- --------------------------------------------------
DEPT_NAME                                                Mgr#
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100002 Shyam
Electricals                                            100007
Smith


10 rows selected.
