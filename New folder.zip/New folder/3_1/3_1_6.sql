--List Staff Code, Staff Name and Salary for those who are getting less than the average salary of organization.


SQL> SELECT staff_code, staff_name, staff_sal from staff_master 
     WHERE staff_sal<(select avg(staff_sal) from staff_master);

STAFF_CODE STAFF_NAME                                          STAFF_SAL
---------- -------------------------------------------------- ----------
    100001 Arvind                                                  17000
    100002 Shyam                                                   20000
    100003 Mohan                                                   24000
    100004 Anil                                                    20000
    100008 Raviraj                                                 18000
    100009 Rahul                                                   22000

6 rows selected.