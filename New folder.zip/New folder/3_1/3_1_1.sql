--Write a query which displays Staff Name, Department Code, Department Name,
--and Salary for all staff who earns more than 20000.


SQL> select s.staff_name, s.dept_code, d.dept_name, s.staff_sal from staff_master s, department_master d 
     where s.dept_code = d.dept_code and
	 s.staff_sal>20000;

STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           STAFF_SAL
-------------------------------------------------- ----------
Mohan                                                      10
Computer Science                                        24000

John                                                       10
Computer Science                                        32000

Allen                                                      30
Electronics                                             42000


STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME                                           STAFF_SAL
-------------------------------------------------- ----------
Smith                                                      20
Electricals                                             62000

Rahul                                                      20
Electricals                                             22000

Ram                                                        30
Electronics                                             32000


6 rows selected.

