--Generate a report which contains the following information.
--Staff Code, Staff Name, Designation Name, Department, Book Code, Book
--Name, Author, Fine For the staff who has not returned the book. Fine will be calculated as Rs. 5 per day.
--Fine = 5 * (No. of days = Current Date – Expected return date). Include records in the table to suit this problem statement

	

SQL> insert into book_transactions values(10000002,1002,100001,'30-APR-17','01-M
AY-17','03-MAY-17');

1 row created.

SQL> SELECT sm.staff_code, sm.staff_name, desg.design_name, d.dept_name, bm.book_code, bm.book_name, bm.book_pub_author,
	 case when round((bt.book_actual_return_date - bt.book_expected_return_date)*5) > 0 then 
	 round((bt.book_actual_return_date - bt.book_expected_return_date)*5) 
	 end case
	 from staff_master sm, designation_master desg, department_master d,  book_transactions bt,  book_master bm 
	 where desg.design_code=sm.design_code and 
	 d.dept_code=sm.dept_code and 
	 bt.staff_code=sm.staff_code and 
	 bm.book_code= bt.book_code;


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          CASE
-------------------------------------------------- ----------
    100001 Arvind
Professor
Electronics                                          10000002

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          CASE
-------------------------------------------------- ----------
Mastersing VC++
P.J Allen


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          CASE
-------------------------------------------------- ----------
    100001 Arvind
Professor
Electronics                                          10000002

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          CASE
-------------------------------------------------- ----------
Mastersing VC++
P.J Allen                                                  10

