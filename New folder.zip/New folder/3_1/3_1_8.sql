--Display Staff Code, Staff Name, and Department Name for those who have taken more than one book.


SQL> select sm.staff_code, sm.staff_name, dm.dept_name from staff_master sm, department_master dm,Book_Transactions bt 
     where sm.staff_code=bt.staff_code and 	bt.staff_code=(select staff_code from book_transactions 
	 group by staff_code 
	 having count(staff_code)>1);

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100001 Arvind
Computer Science

    100001 Arvind
Electricals

    100001 Arvind
Electronics


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100001 Arvind
Mechanics

    100001 Arvind
Robotics

    100001 Arvind
Computer Science


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100001 Arvind
Electricals

    100001 Arvind
Electronics

    100001 Arvind
Mechanics


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100001 Arvind
Robotics


10 rows selected.
