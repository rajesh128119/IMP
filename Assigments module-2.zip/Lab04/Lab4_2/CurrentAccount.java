package com.capgemini;

public class CurrentAccount extends Account {
		private double overDraft=50000.00;
		public void withDraw(double withdraw){
			if(withdraw> overDraft){
			
			}
		}
}
