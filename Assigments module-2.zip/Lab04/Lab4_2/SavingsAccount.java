package com.capgemini;

public class SavingsAccount extends Account {
 final private double minBalance=500;
private double Balance =getBalance();
 public SavingsAccount() {
	super();

}
public SavingsAccount(long accNum, double balance, String name, int age) {
	super(accNum, balance, name, age);
	
}
public void withdraw(double withdraw){
	
	 	if(Balance>=minBalance){
		Balance=Balance-withdraw;
	 	}
	}
@Override
public String toString() {
//super.toString();
	return super.toString()+"SavingsAccount [minBalance=" + minBalance + ", Balance=" + Balance
			+ "]";
}





 
}
