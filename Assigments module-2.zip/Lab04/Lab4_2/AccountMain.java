package com.capgemini;

public class AccountMain {
	public static void main(String[] args) {
		Account acc1=new Account();
		//first user
		int num=acc1.autoGenerate();
		System.out.println("Smith's Account");
		acc1=new Account(num,2000,"Smith",25);
		System.out.println(acc1);
		System.out.println("Depositing 2000 INR to smith account.\nUpdated Balance.");
		acc1.deposit(2000);
		System.out.println(acc1);
		//second user
		Account acc=new SavingsAccount();
		System.out.println("Kathy's Account");
		num=acc.autoGenerate();
		acc=new Account(num,3000,"Kathy",26);
		System.out.println(acc);
		System.out.println("Withdrawing 2000 INR From Kathy account.\nUpdated Balance.");
		acc.withdraw(2000);
		System.out.println(acc);
		
//		Account acc2 = new SavingsAccount();
		acc.withdraw(500);
//		System.out.println(acc.Balance);
//		System.out.println("Saving Account");
		System.out.println(acc);
		
		Person smith=new Person("Smith",23);
		Person Kathy=new Person("Kathy",43);
		//long num=101;
		 acc=new SavingsAccount(num,4000,"smith",23);

		acc.withdraw(2000);
		
		System.out.println(acc);
	}
}
