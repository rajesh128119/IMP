package com.capgemini;

public class Account {
	private long AccNum;
	private double Balance=500.00;
	private Person accHolder;
	static private int autonumber=100;
	public Account() {

		//Balance = 500;
		accHolder=new Person();
	}
	public Account(long accNum, double balance, String name,int age) {
		AccNum = accNum;
		Balance = balance;
		this.accHolder =new Person(name,age);
		autonumber+=1;
	}
	@Override
	public String toString() {
//		super.toString();
		return "Account [AccNum=" + AccNum + ", Balance=" + Balance
				+ ", accHolder=" + accHolder + "]\n";
	}
	
	public long getAccNum() {
		return AccNum;
	}
	public void setAccNum(long accNum) {
		AccNum = accNum;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double amount ){
		Balance=Balance+amount;
	}
	public void withdraw(double withdraw){
		Balance=Balance-withdraw;
	}
	public double getBalance1(){
		return AccNum;
		
	}
	
	public int autoGenerate() {
		
		return autonumber;
		
	}
}
