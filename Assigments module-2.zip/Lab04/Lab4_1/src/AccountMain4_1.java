
public class AccountMain4_1 {

	public static void main(String[] args) {
		Account acc = new Account();
		int num = acc.autoGenerate();
		System.out.println("Smith's Account");
		acc= new Account(num,2000,"Smith",25);
		System.out.println(acc);
		System.out.println("Depositing 200 INR to smith account");
		acc.deposit(2000);
		System.out.println(acc);
		//second user
		System.out.println("Kathy's Account");
		num=acc.autoGenerate();
		acc=new Account(num,3000,"Kathy",26);
		System.out.println(acc);
		System.out.println("Withdrawing 2000 INR from kathy account.\n Updated Balance");
		acc.withdraw(2000);
		System.out.println(acc);
	}

}
