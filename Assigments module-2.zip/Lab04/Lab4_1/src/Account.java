
public class Account extends Person {
private long AccNum;
private double Balance;
private Person accHolder;
static private int autonumber=100;
public Account() {
	Balance = 500;
	accHolder= new Person();
}
public Account(long accNum, double balance, String name,int age)
{
	AccNum=accNum;
	Balance=balance;
	this.accHolder=new Person(name,age);
	autonumber+=1;
}

@Override
public String toString() {
	return "Account [AccNum=" + AccNum + ", Balance=" + Balance
			+ ", accHolder=" + accHolder + "]";
}
public Account(String name, float age) {
	super(name, age);
	// TODO Auto-generated constructor stub
}
public long getAccNum() {
	return AccNum;
}
public void setAccNum(long accNum) {
	AccNum = accNum;
}
public double getBalance() {
	return Balance;
}
public void setBalance(double balance) {
	Balance = balance;
}
public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double amount)
{
	Balance=Balance+amount;
}
public void withdraw(double withdraw)
{
	Balance=Balance-withdraw;
	
}
public double getBalance1()
{
	return AccNum;
}
public int autoGenerate()
{
	return autonumber;
}
}

