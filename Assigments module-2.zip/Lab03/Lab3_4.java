package com.capgemini;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Lab3_4 {
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner scan= new Scanner(System.in);
		System.out.println("enter Date in the format yyyy-mm-dd");
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String line=scan.nextLine();
		LocalDate d1=LocalDate.parse(line,formatter);
		System.out.println("enter Date in the format yyyy-mm-dd");
		line=scan.nextLine();
		LocalDate d2=LocalDate.parse(line,formatter);
		LocalDate end = LocalDate.of(d2.getYear(),d2.getMonth(),d2.getDayOfMonth());
		LocalDate start = LocalDate.of(d1.getYear(),d1.getMonth(),d1.getDayOfMonth());
		Period period= end.until(start);
		
		
		System.out.print("Days: "+period.get(ChronoUnit.DAYS));
		System.out.print("\tMonths:"+period.get(ChronoUnit.MONTHS));
		System.out.print("\tYears:"+period.get(ChronoUnit.YEARS));
	}
}
