package com.capgemini;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

//Lab2_5
public class Person {
	String firstName;
	 String lastName;
	 String FullName="";
	 Period period;
	 long phone;
	public Person() {
	
	}
	public Person(String firstName, String lastName) {

		this.firstName = firstName;
		this.lastName = lastName;	
	}

	
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ ", FullName=" + FullName + ", period=" + period + ", phone="
				+ phone + "]";
	}
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public void calculateAge(LocalDate d) {
		LocalDate end = LocalDate.now();
		LocalDate start = LocalDate.of(d.getYear(),d.getMonth(),d.getDayOfMonth());
		 period=start.until(end);
		
		
	}
	public void concatName() {
			FullName+=firstName+" "+lastName;
	}
	
	public void display()
	{
		System.out.println("Person Details:");
		System.out.println("-------------------");
		System.out.println("FullName"+FullName);
		System.out.println("Phone Number "+phone);
		System.out.println("Age");
		System.out.print("   Years:"+period.get(ChronoUnit.YEARS));
		System.out.print("   Months:"+period.get(ChronoUnit.MONTHS));
		System.out.print("   Days:"+period.get(ChronoUnit.DAYS));
	}
	public void setPhoneNumber(long phone) {
	this.phone=phone;
		
	}

}
