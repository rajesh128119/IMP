package com.capgemini;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_7 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter FirstName");
		String firstName=scan.nextLine();
		System.out.println("Enter LastName");
		String lastName=scan.nextLine();
		Person p=new Person(firstName,lastName);
		System.out.println("Enter DateOfBirth in the format yyyy-mm-dd");
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String line=scan.nextLine();
		System.out.println("Enter Gender:");
		String gen=scan.next();
		System.out.println("Enter Phone number:");
		p.setPhoneNumber(scan.nextLong());
		Gender g;
		if(gen.equals("M"))
		 g=Gender.MALE;
		else
			g=Gender.FEMALE;
		
		
		LocalDate d=LocalDate.parse(line,formatter);
		
		p.concatName();
		p.calculateAge(d);
		p.display();
		System.out.println("\nGender"+g);
		
		
	}
}
