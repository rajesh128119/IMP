package com.capgemini;

import java.util.Scanner;

public class Lab3_1 {

	private static String s;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a String");
		s = scan.nextLine();
		System.out.println("1.Add the string to itself");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the string");
		System.out.println("4.Change odd character to upper case");
		System.out.println("Enter Choice");
		myMethod(scan.nextLine(), scan);

	}

	private static void myMethod(String choice, Scanner scan) {
		String str = "";

		switch (choice) {
		case "1":
			System.out.println("Enter another String");
			str = scan.nextLine();
			s += str;
			System.out.println(s);
			break;
		case "2":
			char[] ch = s.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				if ((i % 2) == 0) {
					ch[i] = '#';
				}
			}
			System.out.println(new String(ch));
			break;
		case "3":
			int count = 0;
			// String rpf="";
			for (int i = 0; i < s.length(); i++) {
				count = 1;
				for (int j = 0; j <= i; j++) {
					if (s.charAt(i) == s.charAt(j)) {
						count++;
					}
				}
				if (count == 2) {
					str += s.charAt(i);
				}
			}
			System.out.println(str);
			break;
		case "4":
			for(int i=0;i<s.length();i++)
			{
				char d =s.charAt(i);
				if((i%2)==0){
				 
				int h=(int)d-32;
					str+=(char)h;
				
				}else
					str+=(char)d;
				
			
			}	System.out.print(str);
			
			break;
		default:
			System.out.println("Enter any one choice");
		}

	}
}
