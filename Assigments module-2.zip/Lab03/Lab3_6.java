package com.capgemini;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class Lab3_6 {
	public static void main(String[] args) {
		ZonedDateTime currentTime =ZonedDateTime.now();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Zone Id(America/New_York)");
		String Id=scan.nextLine();
		ZonedDateTime currentTimeIn = ZonedDateTime.now(ZoneId.of(Id));
		System.out.println("India:"+currentTime);
		System.out.println(Id+": "+currentTimeIn);
		scan.close();
	}
}
