package com.capgemini;



import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Lab3_3 {
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner scan= new Scanner(System.in);
		System.out.println("enter Date in the format yyyy-mm-dd");
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String line=scan.nextLine();
		LocalDate d=LocalDate.parse(line,formatter);
		LocalDate end = LocalDate.now();
		System.out.println("Today's Date:"+end);
		LocalDate start = LocalDate.of(d.getYear(),d.getMonth(),d.getDayOfMonth());
		Period period=start.until(end);
		System.out.print("Days: "+period.get(ChronoUnit.DAYS));
		System.out.print("\tMonths:"+period.get(ChronoUnit.MONTHS));
		System.out.print("\tYears:"+period.get(ChronoUnit.YEARS));
	}
}
