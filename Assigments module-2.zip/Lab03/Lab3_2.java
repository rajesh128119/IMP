package com.capgemini;

public class Lab3_2 {

	public static void main(String[] args) {
		String s = new String("ANTZ");
		boolean b= false;
		int n=s.length();
		int d,e;
		for(int i=0;i<(n-1);i++)
		{
			for(int j=1;j<n;j++)
			{
				d=(int)s.charAt(i);
				e=(int)s.charAt(j);
				if(d<e)
				{
					b=true;
				}
				
				else
					b=false;
			}
		}
		if(b)
			System.out.println(s);
		else System.out.println("not a positive string");
		
		
	}

}
