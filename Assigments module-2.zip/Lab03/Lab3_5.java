package com.capgemini;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_5 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		System.out.println("Enter purchase Date in the format yyyy-mm-dd");
		String line = scan.nextLine();
		LocalDate d1=LocalDate.parse(line,formatter);
		System.out.println("Enter Waarntee in terms of months ");
		
		int month=scan.nextInt();
		do
		{
			if(month<0)
			{
			System.out.println("Enter month in positive");
			month=scan.nextInt();
		
			}
			else{
			System.out.println("The Expiry Date is:");
		System.out.print(d1.plusMonths(month));
		break;
			}
			}while(true);
		
	}

}
