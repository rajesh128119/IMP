package com.capgemini;
//Lab 7_2
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ArraySortUsingArrayList {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		String []products = {"SD","AC","FD","DE","ZW"};
		
		for (String prod : products) {
			list.add(prod);
		}
		System.out.println(list );
		Collections.sort(list);
		System.out.println(list);
		//reverse order
		Collections.sort(list,Collections.reverseOrder());
		System.out.println(list);
	
	}
}
