package com.capgemini;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.server.Emp;
import com.capgemini.service.EmpService;
import com.capgemini.service.EmpServiceImpl;

public class Client {
	static Emp emp = null;
	static Scanner scan = new Scanner(System.in);
    static EmpService eSerivce = new EmpServiceImpl();
	public static void main(String[] args) {
		do{
		System.out.println("Choose option from below");
		System.out.println("1. Save Employee");
		System.out.println("2. Insurance Scheme for employee");
		System.out.println("3. Display Details of Employee");
		System.out.println("4. Delete an employee");
		System.out.println("5. Sort an employee");
		System.out.println("6. Enter the Insurance scheme to get employee details");
		System.out.println("7. Exit");
		String choice=scan.nextLine();
		executeCase(choice);
		}while(true);
	}
	private static void executeCase(String choice) {
       
	  Object savedEmp;
	switch(choice)
	  {
	  case "1" : 
		  		System.out.println("To save the details of the employee");
		  		System.out.println("Enter the id of the Employee");
		  		int id =0;
		  		do{
		  			try{
		  				id=scan.nextInt();
				  		break;	
		  			}catch(InputMismatchException e)
		  			{
		  				System.out.println("Please enter the id in numbers only");
		  			}
		  					  				  					
		  		}while(true);
		  		
		  	boolean nameValid=false;
		  	String name=null;
		  	System.out.println("Enter the name");
		  	while(!nameValid)
		  	{
		  		name = scan.nextLine();
		  		nameValid=eSerivce.Validatename(name);
		  		if(!nameValid)
		  		{
		  			System.out.println("Please enter the name Starting with First Caps");
		  		}
		  	}
		
		  	System.out.println("Enter the Salary of the Employee");
		  	double salary = scan.nextDouble();
		  	System.out.println("Enter the Designation of the Employee");
		  	String designation = scan.next();
		  	String insuranceScheme=eSerivce.setinsurance(salary,designation);
		  	emp = new Emp(id,name,salary,designation,insuranceScheme);
		  	eSerivce.addEmployee(emp);
		  	System.out.println(emp);
		  	break;
	  
	  case "2" : System.out.println("Enter the salary or designation");
	  			 String value= scan.nextLine();
	  			 String scheme = null;
	  			 try
	  			 {
	  				 int value1 = Integer.parseInt(value);
	  				 scheme = eSerivce.setinsurance(value1, "");
	  				 System.out.println(scheme);
	  			 }catch (NumberFormatException e) {
	  				System.out.println(value);
	  				scheme = eSerivce.setinsurance(0, value);
	  				System.out.println(scheme);
					}
	  			 break;
	  			 
	  case "3" :
		  Emp savedEmp1;
		  savedEmp1 = eSerivce.showEmployee();
	  
		  System.out.println(savedEmp1);
	 
		   
	  
	  	break;
	  
	  case "4":
	  		System.out.println("Enter employee ID to delete");
	  		int empid = scan.nextInt();
	  		boolean delete = eSerivce.deleteEmployee(empid);
	  		System.out.println(delete);
	  		  break;
	  
	  case"5":
	  		TreeSet savedTree = eSerivce.sortedEmp();
	  		System.out.println(savedTree);
	  		break;
	  		
	  case "6" : 
		  		System.out.println("Enter insurance scheme");
		  		String insurance = scan.next();
		  		Set set = eSerivce.getEmployeeDetails(insurance);
		  		System.out.println(set);
		  		break;
	  case "7":
		  		System.out.println("Thanks for using the application");
		  		System.exit(0);
		  		break;
	  		
	   default:
		   	break;
	  }
		
	}

}
