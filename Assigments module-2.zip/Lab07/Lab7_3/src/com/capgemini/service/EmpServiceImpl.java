package com.capgemini.service;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.server.Emp;

public class EmpServiceImpl implements EmpService {

	HashMap<Integer,Emp> savedEmp= new HashMap();
	Emp emp = new Emp();

	public EmpServiceImpl() {

	}

	@Override
	public boolean Validatename(String name) {
		return name.matches("[A-Z][A-Za-z]*") ;
	}



	@Override
	public String setinsurance(double salary, String designation) {
	String insuranceScheme=null;
	if((salary<5000)||(designation.equalsIgnoreCase("Clerk")))
	{
		insuranceScheme="No Scheme";
	}
	else
		if((salary>=40000)||(designation.equalsIgnoreCase("Manager")))
		{
			insuranceScheme="Scheme A";
		}
		else
			if(((salary>=20000)&&(salary<40000))||((designation.equalsIgnoreCase("Programmer"))))
			{
				insuranceScheme="Scheme B";
			}
			else
				if(((salary>=5000)&&(salary<20000))||((designation.equalsIgnoreCase("System Associate"))))
				{
					insuranceScheme="Scheme C";
				}
			
		return insuranceScheme;
	}


	@Override
	public void addEmployee(Emp emp) {
		BufferedWriter bw;
		try {
			bw=new BufferedWriter(new FileWriter("Employee.txt",true));
			bw.write(emp.getId()+","+emp.getName()+","+emp.getSalary()+","+emp.getDesignation()+","+emp.getInsuranceSchema());
			bw.newLine();
			bw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		savedEmp.put(emp.getId(),emp);
			
		}
	@Override
	public boolean deleteEmployee(int empid) {
		boolean delete = false;
		if(savedEmp.size()>0)
		{
			savedEmp.remove(empid);
			delete=true;
		}
			return delete;
		
	}

	@Override
	public TreeSet sortedEmp() {
TreeSet t = new TreeSet<>();
	Set<Integer> keys=savedEmp.keySet();
	for(Integer id :keys)
	{
		t.add(savedEmp.get(id));
	}
	return t;
	}

	@Override
	public Set getEmployeeDetails(String insurance) {
		Set<Integer> set = savedEmp.keySet();
		Set<Emp> empSet = new HashSet<>();
		for(Integer id:set)
		{
			Emp emp = savedEmp.get(id);
			if(insurance.equals(emp.getInsuranceSchema()))
			{
				empSet.add(emp);
			}
		}
		return empSet;
	}

	@SuppressWarnings("null")
	@Override
	public Emp showEmployee() {
		BufferedReader br;
try {
	br = new BufferedReader(new FileReader("Employee.txt"));
	String line=null;
	while((line=br.readLine())!=null)
	{
		String[] values = null;
		 emp = new Emp(Integer.parseInt(values[0]), values[1],
				 Double.parseDouble(values[2]), values[3], values[4]);
		
		System.out.println(emp);
	}
			
} catch (FileNotFoundException e) {
	
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

		return emp;
	}

}
