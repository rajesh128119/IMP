package com.capgemini;
//Lab7_1
import java.util.TreeSet;

public class ArraysSort {

	public static void main(String[] args) {
		TreeSet<String> tSet = new TreeSet<>();
		String [] products = {"SA","QB","AC","CD","AE"};
		for (String prod : products) {
			tSet.add(prod);	
		}
		System.out.println(tSet);
		
		

	}

}
