import java.util.Scanner;

public class lab14_2 {

	public interface Calculator1 {

		Object calculate1(String x);

	}

	public lab14_2() {
		Calculator1 string =(String x)->x.split(",");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the string");
		String x = scan.nextLine();
		System.out.println("String" +getValue(x,string));
	}
	private Object getValue(String x, Calculator1 calc) {
		return calc.calculate1(x);
	}
	
	public static void main(String[] args) {
		 new lab14_2();

	}



}
