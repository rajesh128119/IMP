
public interface Calculator {

	Object calculate(int first, int second);
    
}
