import java.util.Scanner;



public class lab14_1 {
	
	public  lab14_1() {
		Calculator sum =(int first, int second)->Math.pow(first, second);
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the values of x");
		int x=scan.nextInt();
		System.out.println("Enter the values of y");
		int y =scan.nextInt();
		System.out.println("xpow(y)" +getValue(x,y,sum));

		return;
	}
		
	public Object getValue(int first,int second,Calculator calc)
	{
		return calc.calculate(first,second);
	}
public static void main(String[] args) {
	new lab14_1();
}

}
