
public interface calculator1 {
}
