package com.capgemini.ui;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.dao.Message;
import com.capgemini.exception.UserDefinedException;
import com.capgemini.services.pService;
import com.capgemini.services.pServiceImpl;

public class Client {

	static Scanner scan = new Scanner(System.in);
	static pService pSerivce = new pServiceImpl();
	static Map<Integer, Integer> hmap = new HashMap<>(); 

	public static void main(String[] args) {
		while(true)
		{
		System.out.println("Choose option from below");
		System.out.println("1. Insert the purchase Details and Update the quantity in shop");
		System.out.println("2. View Details of Mobile");
		System.out.println("3. Delete a mobile available in the Shop");
		System.out.println("4. Search mobile on basis of price range");
		System.out.println("5. Exit");
		String choice = scan.nextLine();
		executecase(choice);
		}
	}

	private static void executecase(String choice) {
		PurchaseDetail pdetail;
		String name=null;
		String email=null;
		String phoneno=null;
		int MobileId=0;
		
		
		switch (choice) {
		case "1":
			System.out.println("****Enter The Details of the Customer and mobile****");
			boolean nameValid =false;

			while(!nameValid)
			{
				System.out.println("Enter the Customer Name");
				name=scan.next();
				nameValid=pSerivce.ValidateName(name);
				if(!nameValid)
				{
					System.out.println("Please enter valid name starting with UpperCase and have alphabets only");

				}

			}

			boolean emailValid =false;
			while(!emailValid)
			{
				System.out.println("Enter the Customer emailId");
				email=scan.next();
				emailValid=pSerivce.Validateemail(email);
				if(!emailValid)
				{
					System.out.println("Enter the valid emailId");

				}

			}
			boolean phoneVaild=false;
			while(!phoneVaild)
			{
				System.out.println("Enter the Phone number");
				phoneno=scan.next();
				phoneVaild=pSerivce.Validatephone(phoneno);
				if(!phoneVaild)
				{
					System.out.println("Please enter in numbers only ,and 10 digits");

				}

			}
			Date purchaseDate = new Date();
		
			while(true)
			{
			Map<Integer,Integer> mobmap=pSerivce.getMapmap();
			System.out.println(mobmap);
			System.out.println("Enter Mobile ID");
			MobileId=scan.nextInt();
			boolean check=pSerivce.mobileId(MobileId);
			if(check==true)
			{
				break;
			}
			System.out.println("Enter correct mobile id");
			
			}
			
			
			PurchaseDetail pdetails= new PurchaseDetail(name, email, phoneno, MobileId);
			boolean save=false;
			try {
				save=pSerivce.savedetails(pdetails);
			} catch (UserDefinedException e) {
				System.out.println("User defined Exception"+Message.SQL_EXCEPTION);
			}
			if(save){
				System.out.println("Details Saved");
				System.out.println(" With mobileid :"+MobileId);
//				int rows=0;
//				if(rows>0)
//					try {
//					rows = pSerivce.Updatemobile(MobileId);
//					System.out.println("Rows updated"+rows);
//						}
//				
//					catch (UserDefinedException e) {
//					System.out.println("User Define Exception"+e.getMessage());
//				}
				
			}
			break;
			
		case "2":System.out.println("The mobies available in the shop are");
			Collection<Mobile> mobiles;
			try {
				mobiles = pSerivce.viewAllMobile();
				System.out.println(mobiles);
			}	catch (UserDefinedException e) {
				System.out.println(e.getMessage());
			}
		         
					
		break;

		case "3":  System.out.println("To delete a mobile enter the mobile Id");
					int id=scan.nextInt();
					pSerivce.deleteMobile(MobileId);
					break;
		
		case"4"	:  System.out.println("To Search the mobile please enter the min price");
					try
					{int min = scan.nextInt();
					System.out.println("Please enter the max id");
					int max = scan.nextInt();
					if(max>min)
					{
					Collection<Mobile> mobiles1 =pSerivce.searchMobile(min,max);
					for(Mobile mobile:mobiles1)
					{
						System.out.println(mobile);
					}
					}
					else
					{
						System.out.println("Enter the valid range");
					}
					}catch(InputMismatchException e)
					{
						System.out.println("Please enter in numeric values only");
					}
					break;
					
		case"5" :	System.out.println("Thank you for using the application");
					System.exit(0);;
					
		default:
					System.out.println("Please enter the correct choice");
			break;
		}
		

	}
}
