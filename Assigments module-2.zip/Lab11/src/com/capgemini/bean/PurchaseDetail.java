package com.capgemini.bean;

import java.util.Date;

public class PurchaseDetail {

private String cname;
private String mailid;
private String phoneno;
private int mobileId;
private Date purchasedate;
public PurchaseDetail() {
	super();
	// TODO Auto-generated constructor stub
}
public PurchaseDetail(String cname, String mailid, String phoneno,
		int mobileId) {
	super();
	this.cname = cname;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.mobileId = mobileId;
	//this.purchasedate = purchasedate;
}
@Override
public String toString() {
	return "PurchaseDetail [cname=" + cname + ", mailid=" + mailid
			+ ", phoneno=" + phoneno + ", mobileId=" + mobileId
			+ ", purchasedate=" + purchasedate + "]";
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public Date getPurchasedate() {
	return purchasedate;
}
public void setPurchasedate(Date purchasedate) {
	this.purchasedate = purchasedate;
}
}