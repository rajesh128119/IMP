package com.capgemini.bean;

public class Mobile {

	private int mobileId;
	private String mobileNo;
	private double price;
	private int quantity;
	
	public Mobile(int mobileId, String mobileNo, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mobileNo = mobileNo;
		this.price = price;
		this.quantity = quantity;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobileNo=" + mobileNo
				+ ", price=" + price + ", quantity=" + quantity + "]\n";
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
