package com.capgemini.dao;

import java.util.Collection;
import java.util.Map;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.exception.UserDefinedException;

public interface PurchaseDao {

	boolean addPurchaseDetails(PurchaseDetail pdetail) throws UserDefinedException;

	int updateQuantity(int i) throws UserDefinedException;

	Collection<Mobile> viewAllMobile() throws UserDefinedException;

	boolean deleteMobile(int mobileId);

	Collection<Mobile> searchMobile(int min, int max);

	Map<Integer, Integer> getmobmap();


}
