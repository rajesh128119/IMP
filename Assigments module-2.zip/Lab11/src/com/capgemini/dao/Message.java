package com.capgemini.dao;

public class Message {

	public static final String SQL_EXCEPTION = "Unable to connect to database";
	public static final String UPDATE_NOT_POSSIBLE = "Currently update is not possible";
	public static final String LIST_MOBILE = "Mobile list not available right now";

}
