package com.capgemini.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.exception.UserDefinedException;

public class DaoJunitTest {
	 PurchaseDaoImp pDao;
	 PurchaseDetail pdetail;
	 int min;
	 int max;
	 
	@Before
	public void setUp() throws Exception {
		pDao=new PurchaseDaoImp();
		pdetail = new PurchaseDetail("Kajal", "Kajal@gmail.com", "978786786",1002);
		min=8000;
		max=15000;
	System.out.println("Before");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("After");
	}

	@Test//(expected=NullPointerException.class)
	public void testAddPurchaseDetails() throws UserDefinedException {
		boolean valid=false;
		valid =pDao.addPurchaseDetails(pdetail);
		assertTrue(valid);
		
		
	}
	@Test//(expected=NullPointerException.class)
	public void testSearch() {
		ArrayList<Mobile> list= (ArrayList<Mobile>) pDao.searchMobile(min, max);
		if(list!=null){
			assertTrue(true);
		}else assertTrue(false);
		
	}

}
