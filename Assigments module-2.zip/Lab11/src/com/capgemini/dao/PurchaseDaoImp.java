package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.exception.UserDefinedException;
import com.capgemini.util.DBUtil;

public class PurchaseDaoImp implements PurchaseDao {
	Logger logger = Logger.getLogger(PurchaseDaoImp.class);
	Map<Integer,Integer> mobmap=new HashMap<Integer, Integer>();
	
	Connection  conn = null;
	PreparedStatement pstmt;
	static String mobQuery="Select mobileid,quantity from mobiles where quantity>0";

	public PurchaseDaoImp() {
	conn=DBUtil.getConnection();
	try {
		pstmt=conn.prepareStatement(mobQuery);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			mobmap.put(rs.getInt(1), rs.getInt(2));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	@Override
	public boolean addPurchaseDetails(PurchaseDetail pdetail) throws UserDefinedException {
		boolean saved = true;
	
		conn = DBUtil.getConnection();
		
		String insertQuery = "insert into purchasedetails(purchaseid,cname,maildid,phone,purchasedate,mobileid) values(purchase_seq.NEXTVAL,?,?,?,sysdate,?)  ";
		try {
			conn.setAutoCommit(false);
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setString(1, pdetail.getCname());
			pstmt.setString(2, pdetail.getMailid());
			pstmt.setString(3, pdetail.getPhoneno());
			pstmt.setInt(4, pdetail.getMobileId());
			int rows = pstmt.executeUpdate();
			if(rows>0)
				updateQuantity(pdetail.getMobileId());
				saved=true;
			logger.info("saved details are"+pdetail);
			conn.commit();
				} catch (SQLException e) {
			throw new UserDefinedException(Message.SQL_EXCEPTION);
		}
		
		return saved;
	}
	String updateQuery = "update mobiles set quantity=(quantity-1) where mobileid=? ";
	@Override
	public int updateQuantity(int mobileid) throws UserDefinedException {
			int rows=0;
		try {conn.setAutoCommit(false);
			conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(updateQuery);
			pstmt.setInt(1, mobileid);
			rows=pstmt.executeUpdate();
			conn.commit();
			System.out.println("Mobile quantity updated by 1");
		} catch (SQLException e) {
           throw new UserDefinedException(Message.UPDATE_NOT_POSSIBLE);
		}
		
		
		return rows;		

				
	}
	@Override
	public Collection<Mobile> viewAllMobile() throws UserDefinedException {
      ArrayList mobiles =  new ArrayList<>();
      conn= DBUtil.getConnection();
      try {
		Statement st =conn.createStatement();
		ResultSet rs = st.executeQuery("Select * from mobiles");
		while(rs.next())
		{
			int mobileId=rs.getInt(1);
			String mobileName = rs.getString(2);
			double price = rs.getDouble(3);
			int quantity = rs.getInt(4);
			Mobile mobile = new Mobile(mobileId, mobileName, price, quantity);
			mobiles.add(mobile);
				}
		return mobiles;
	} catch (SQLException e) {
		throw new UserDefinedException(Message.LIST_MOBILE);
	}
	}
	@Override
	public boolean deleteMobile(int mobileId) {
		conn=DBUtil.getConnection();
		try {
			pstmt=conn.prepareStatement("Delete from mobiles where mobileId=?");
			pstmt.setInt(1, mobileId);
			int rows =pstmt.executeUpdate();
			if(rows>0)
			{
				return true;
			}
			logger.info("mobile delete"+mobileId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	@Override
	public Collection<Mobile> searchMobile(int min, int max) {
		ArrayList mobiles = new ArrayList();
		
		conn=DBUtil.getConnection();
		
		
		try {
			pstmt=conn.prepareStatement("SELECT * FROM mobiles WHERE price BETWEEN ? AND ?");
			pstmt.setDouble(1, min);
			pstmt.setDouble(2, max);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				int mobileId =rs.getInt(1);
				String mobileName = rs.getString(2);
				double price = rs.getDouble(3);
				int quantity = rs.getInt(4);
				Mobile mobile = new Mobile(mobileId, mobileName, price, quantity);
				mobiles.add(mobile);
				
			}
			logger.info("Search details are minprice entered="+min+"max price entered is"+max);
			return mobiles;
		}catch (SQLException e){ 
			
		}
	
		
			
		return null;
	}
	@Override
	public Map<Integer, Integer> getmobmap() {
		// TODO Auto-generated method stub
		return mobmap;
	}

	}


	
	



