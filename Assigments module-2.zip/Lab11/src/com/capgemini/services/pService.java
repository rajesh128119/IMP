package com.capgemini.services;

import java.util.Collection;
import java.util.Map;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.exception.UserDefinedException;

public interface pService {

	boolean ValidateName(String name);

	boolean Validateemail(String email);



	boolean savedetails(PurchaseDetail pdetail) throws UserDefinedException;

	boolean Validatephone(String phoneno);

	int Updatemobile(int mobileId) throws UserDefinedException;

	Collection<Mobile> viewAllMobile() throws UserDefinedException;

	boolean deleteMobile(int mobileId);

	Collection<Mobile> searchMobile(int min, int max);

	Map<Integer, Integer> getMapmap();

	boolean mobileId(int mobileId);

	

}
