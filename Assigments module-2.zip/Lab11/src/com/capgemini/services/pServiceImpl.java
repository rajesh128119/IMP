package com.capgemini.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetail;
import com.capgemini.dao.PurchaseDao;
import com.capgemini.dao.PurchaseDaoImp;
import com.capgemini.exception.UserDefinedException;

public class pServiceImpl implements pService {
	 PurchaseDao pDao; 
	public pServiceImpl() {
		pDao = new PurchaseDaoImp();
		
	}

	@Override
	public boolean ValidateName(String name) {
		// TODO Auto-generated method stub
		return name.matches("[A-Z][a-zA-Z]{1,20}");
	}

	@Override
	public boolean Validateemail(String email) {
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}

	

	@Override
	public boolean savedetails(PurchaseDetail pdetail) throws UserDefinedException {
		
		return pDao.addPurchaseDetails(pdetail);
		
		
	}

	@Override
	public boolean Validatephone(String phoneno) {
			return phoneno.matches("[7-9]{1}[0-9]{9}");
	}

	@Override
	public int Updatemobile(int mobileid) throws UserDefinedException {
	System.out.println(mobileid);
		return pDao.updateQuantity(mobileid);
	}

	@Override
	public Collection<Mobile> viewAllMobile() throws UserDefinedException {
		// TODO Auto-generated method stub
		return pDao.viewAllMobile();
	}

	@Override
	public boolean deleteMobile(int mobileId) {
		
		return pDao.deleteMobile(mobileId);
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection<Mobile> searchMobile(int min, int max) {
		// TODO Auto-generated method stub
		return pDao.searchMobile(min,max);
	}

	@Override
	public Map<Integer, Integer> getMapmap() {
		// TODO Auto-generated method stub
		return pDao.getmobmap();
	}

	@Override
	public boolean mobileId(int mobileId) {
		Map<Integer, Integer> mobmap = pDao.getmobmap();
				return mobmap.containsKey(mobileId);
	}



	

}
