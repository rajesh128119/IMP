package com.capgemini.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {
static Connection conn;
static ResourceBundle bundle;
//static OracleDataSource ods;
static{
//	try {
		 bundle = ResourceBundle.getBundle("Resource/data");
//		ods=new OracleDataSource();
//	} catch (SQLException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
}


	public static Connection getConnection()
	{ try {
		if(conn==null||conn.isClosed())
		{
			String url = bundle.getString("URL");
			String password = bundle.getString("PASSWORD");
			String driver = bundle.getString("DRIVER");
			String user = bundle.getString("USER");
			Class.forName(driver);
			conn = DriverManager.getConnection(url,user,password);
		//conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
//			ods.setURL("jdbc:oracle:thin:@localhost:1521:XE");
//			ods.setUser("system");
//			ods.setPassword("sys");
//			ods.setDriverType("thin");
//			ods.setNetworkProtocol("tcp");
//			conn = ods.getConnection();
			
		}} catch (SQLException e) {
	
	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return conn;
		
	}
		

		
		
		
	
	

}

