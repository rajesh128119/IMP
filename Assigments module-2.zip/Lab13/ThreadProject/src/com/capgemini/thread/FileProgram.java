package com.capgemini.thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class FileProgram {
	public static void main(String[] args) {
	
		BufferedReader br;
		BufferedWriter bw;
		try {
			br=new BufferedReader(new FileReader("source.txt"));
			bw = new BufferedWriter(new FileWriter("target.txt"));
			Thread t = new CopyDataThread(br,bw);
			t.start();
		} catch (FileNotFoundException e) {
			System.out.println("FileNot Found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IOException");
		}
		
	}

}
