package com.capgemini.thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;




public class CopyDataThread extends Thread{
		BufferedReader br =null;
		BufferedWriter bw=null;
	public CopyDataThread(BufferedReader br, BufferedWriter bw) {
		this.br=br;
		this.bw=bw;
	}String line =null;
	char[] ch;
	public void run()
	{
		
		try {
			while((line=br.readLine())!=null){
				ch=line.toCharArray();
				
				System.out.println(ch.length);
				for(int i=0;i<ch.length;i++)
				{
					System.out.print(ch[i]);
					bw.write(ch[i]);

					
			
					if((i+1)%10==0){
						bw.newLine();	bw.flush();
						System.out.println("10 characters are entered");
						Thread.sleep(5000);
					}
				}
				
				//System.out.println(ch);
				
			}
			
		} catch (IOException e) {
			System.out.println("Cannot write to bufferwriter");
		
		} catch (InterruptedException e) {
			System.out.println("InterruptedException");
		}
	}
	
}
