package com.capgemini;

public class Lab2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = Integer.parseInt(args[0]);
			if(number>0)
			{
				System.out.println("positive number");
			}
			else if(number<0)
			{
				System.out.println("negative number");
			}
			else
			{
				System.out.println("Zero");
			}
	}

}
