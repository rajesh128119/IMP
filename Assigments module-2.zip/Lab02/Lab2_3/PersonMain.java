//main class
package com.capgemini;

public class PersonMain {
	public static void main(String[] args) {
		Person p=new Person("Divya"," Bharti",'F');
		p.display();
	}
}