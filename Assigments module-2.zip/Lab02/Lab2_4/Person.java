//person class for the transfer objects
package com.capgemini;
//Lab2_4
public class Person {
	String firstName;
	 String lastName;
	 char gender;
	 long phone;
	 
	public Person() {
	
	}
	public Person(String firstName, String lastName, char gender) {

		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		
	}
	public void display()
	{
		System.out.println("Person Details:");
		System.out.println("-------------------");
		System.out.println("Firstname:"+firstName);
		System.out.println("LastName:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("phone No:"+phone);
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + "]";
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void setPhoneNumber(long phone) {
		this.phone = phone;
		phone=getPhone();
	}
	public long getPhone()
	{
		return phone;
	}
	
	
}
