//personMain class
package com.capgemini;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		Person p=new Person("Divya"," Bharti",'F');
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Phone number:");
		p.setPhoneNumber(s.nextLong());
		p.display();
	}
}