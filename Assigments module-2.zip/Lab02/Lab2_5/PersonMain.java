//PersonMain class
package com.capgemini;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		Person p=new Person("Divya"," Bharti");
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Phone number:");
		p.setPhoneNumber(s.nextLong());
		System.out.println("Enter Gender:");
		String gen=s.next();
		Gender g;
		if(gen.equals("M"))
		 g=Gender.MALE;
		else
			g=Gender.FEMALE;
		p.display();
		System.out.println("Gender: "+g);
		s.close();
		
	}
}