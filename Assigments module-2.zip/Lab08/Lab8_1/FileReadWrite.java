package com.capgemini;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadWrite {
	public static void main(String[] args) {
		FileReader fr= null;
		BufferedReader br=null;
		FileWriter fw=null;
		BufferedWriter bw =null;
		try {
			fr =new FileReader("our.txt");
			br= new BufferedReader(fr);
			String line =null;
			fw= new FileWriter("our1.txt");
			bw = new BufferedWriter(fw);
			while((line=br.readLine())!=null){
				//System.out.println(line);
				StringBuilder sb= new StringBuilder(line);
				sb.reverse();
				
				bw.write(sb.toString());
				
			}System.out.println("task completed");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		finally{
			try {
				bw.close();
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
				
		
}
}
