package com.capgemini;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadNumberFromFile {
	public static void main(String[] args) {
		FileReader fr= null;
		BufferedReader br = null;
		Scanner scan;
		try {
			fr=new FileReader("numbers.txt");
			br= new BufferedReader(fr);
			String line=null;
			while((line = br.readLine())!=null){
			scan = new Scanner(line).useDelimiter(",");
			while(scan.hasNextInt()){
				int num=scan.nextInt();
				if(num%2==0)
				System.out.print(" "+num);
			}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
