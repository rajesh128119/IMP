package com.capgemini.service;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.server.Emp;

public interface EmpService {

	boolean Validatename(String name);



	String setinsurance(double salary, String designation);



	HashMap showEmployee();



	boolean deleteEmployee(int empid);



	TreeSet sortedEmp();



	Set getEmployeeDetails(String insurance);



	void addEmployee(Emp emp);

}
