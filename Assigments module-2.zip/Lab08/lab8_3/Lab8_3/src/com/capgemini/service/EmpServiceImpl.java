package com.capgemini.service;



import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.server.Emp;

public class EmpServiceImpl implements EmpService {

	HashMap<Integer,Emp> savedEmp= new HashMap();

	public EmpServiceImpl() {

	}

	@Override
	public boolean Validatename(String name) {
		return name.matches("[A-Z][A-Za-z]*") ;
	}



	@Override
	public String setinsurance(double salary, String designation) {
	String insuranceScheme=null;
	if((salary<5000)||(designation.equalsIgnoreCase("Clerk")))
	{
		insuranceScheme="No Scheme";
	}
	else
		if((salary>=40000)||(designation.equalsIgnoreCase("Manager")))
		{
			insuranceScheme="Scheme A";
		}
		else
			if(((salary>=20000)&&(salary<40000))||((designation.equalsIgnoreCase("Programmer"))))
			{
				insuranceScheme="Scheme B";
			}
			else
				if(((salary>=5000)&&(salary<20000))||((designation.equalsIgnoreCase("System Associate"))))
				{
					insuranceScheme="Scheme C";
				}
			
		return insuranceScheme;
	}

	@Override
	public HashMap showEmployee() {
		return savedEmp;
	}
	@Override
	public void addEmployee(Emp emp) {
		BufferedWriter bw;
	try{
		bw=new BufferedWriter(new FileWriter("Employee.txt",true));
		bw.write(emp.getId()+","+emp.getName()+","+emp.getSalary()+","+emp,getDesignation()+","+emp.getInsuranceSheme());
		bw.newLine();
		bw.flush();
			}catch(IOException e)
	{
				
	}
	
	}
	@Override
	public boolean deleteEmployee(int empid) {
		boolean delete = false;
		if(savedEmp.size()>0)
		{
			savedEmp.remove(empid);
			delete=true;
		}
			return delete;
		
	}

	@Override
	public TreeSet sortedEmp() {
TreeSet t = new TreeSet<>();
	Set<Integer> keys=savedEmp.keySet();
	for(Integer id :keys)
	{
		t.add(savedEmp.get(id));
	}
	return t;
	}

	@Override
	public Set getEmployeeDetails(String insurance) {
		Set<Integer> set = savedEmp.keySet();
		Set<Emp> empSet = new HashSet<>();
		for(Integer id:set)
		{
			Emp emp = savedEmp.get(id);
			if(insurance.equals(emp.getInsuranceSchema()))
			{
				empSet.add(emp);
			}
		}
		return empSet;
	}

}
