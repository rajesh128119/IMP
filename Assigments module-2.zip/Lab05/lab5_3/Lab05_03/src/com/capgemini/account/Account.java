package com.capgemini.account;




abstract public class Account {
	
	public abstract void withDraw(double minBalance);
}
