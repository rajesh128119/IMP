package com.capgemini.account;

public class AccountMainImpl {
	public static void main(String[] args) {
	
		Account accm = new AccountMain(100,3000,"Smith",25);
		System.out.println("Smith's Account\n"+accm);
		accm.withDraw(2000);
		System.out.println("After withdrawing balance..\n"+accm);
	}
	
}
