package com.capgemini.account;

import com.capgemini.person.Person;

public class AccountMain  extends Account{
	private long accNum;
	private double Balance;
	private Person accHolder;
	public AccountMain() {
	}
	public AccountMain(long accNum, double balance, String name,float age) {
		this.accNum = accNum;
		Balance = balance;
		this.accHolder = new Person(name,age);
	}





	@Override
	public void withDraw(double minBalance) {
		Balance=Balance-minBalance;
	}


	


	@Override
	public String toString() {
		return "AccountMain [accNum=" + accNum + ", Balance=" + Balance
				+ ", accHolder=" + accHolder + "]";
	}
	public double getBalance() {
		return Balance;
	}


	public void setBalance(double balance) {
		Balance = balance;
	}


}
