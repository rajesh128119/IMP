package com.cg.eis.service;






public class EmpService implements EmpServiceImpl {
	
	@Override
	public String assignScheme(double salary, String designation) {
		String scheme =null;
		if((salary>5000 &&salary<20000)||(designation.equalsIgnoreCase("System Associate"))){
			scheme="Scheme C";
		}else if((salary>=20000 && salary<40000)||(designation.equalsIgnoreCase("Programmer"))){
			scheme="Scheme B";
		}else if(salary>=40000||designation.equalsIgnoreCase("Manager")){
			scheme="Scheme A";
		}else{
			scheme="No Scheme";
		}
		return scheme;
	}

	@Override
	public boolean validateName(String name) {
		
		return name.matches("[A-z][a-zA-Z]*");
	}



}
