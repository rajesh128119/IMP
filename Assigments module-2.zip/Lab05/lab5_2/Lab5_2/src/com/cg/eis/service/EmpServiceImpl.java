package com.cg.eis.service;



public interface EmpServiceImpl {

	String assignScheme(double salary, String designation);

	boolean validateName(String name);

//	String getScheme(int value1);



}
