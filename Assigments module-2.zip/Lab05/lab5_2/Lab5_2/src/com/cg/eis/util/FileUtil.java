package com.cg.eis.util;


import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {

	public static FileWriter getWriter(String string) {
		FileWriter fw = null;
		
		try {
			fw = new FileWriter("emp.ser");
			
		} catch (IOException e) {
	
			e.printStackTrace();
		}
		return fw;
	}

}
