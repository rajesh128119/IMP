package com.cg.eis.pl;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmpService;
import com.cg.eis.service.EmpServiceImpl;

public class Client {
	static Scanner scan;
	static Employee emp;
	static EmpServiceImpl eService = new EmpService();
	@SuppressWarnings("rawtypes")
	static HashMap savedEmp = new HashMap();

	public static void main(String[] args) {
		scan = new Scanner(System.in);
		do{
		System.out.println("\n\n1.Get Employee details from user");
		System.out.println("2.Find the Insurance scheme for an employee based on salary and designation.");
		System.out.println("3.Display all the details of an employee");
		System.out.println("4.Exit");
		String choice = scan.nextLine();
		executeCase(choice);
		}while(true);
	}

	private static void executeCase(String choice) {
		int id = 0;
		String name = null;
		String designation = null;
		double salary;
		
		switch (choice) {
		case "1":
			System.out.println("Enter employee Id");
			do {
				try {
					id = scan.nextInt();
					break;
				} catch (InputMismatchException e) {
					System.out.println("Enter number only");
					scan.nextLine();
				}
			} while (true);
			boolean nameValid = false;

			while (!nameValid) {
				System.out.println("Name should start with uppercase and have alphabets only..");
				name = scan.next();
				nameValid = eService.validateName(name);
			}
			System.out.println("Enter Salary:");
			salary = scan.nextDouble();
			System.out.println("Enter designation");
			designation = scan.next();
			String InsuranceSchema = eService.assignScheme(salary, designation);
			emp = new Employee(id, name, salary, designation, InsuranceSchema);
			System.out.println(emp);

			System.out.println("Employee Details Saved.." + emp);

			break;
		case "2": System.out.println("Enter salary or designation..");
		          String value = scan.nextLine();
		          String scheme=null;
		          try{
		          int value1 = Integer.parseInt(value);
		          scheme = eService.assignScheme(value1,"");
		          System.out.println(scheme);
		          }catch(NumberFormatException e){
		        	  System.out.println(value);
		        	  scheme =eService.assignScheme(0, value);
		        	  System.out.println(scheme);
		        	  
		          }
//		          System.out.println(value1);
			break;
		case "3":
			if (emp != null)
				System.out.println("Emp details.." + emp);
			else
				System.out.println("Sorry!! No employee Saved");
				break;
		case "4":
			System.out.println("Thanks for using app..");
			System.exit(0);
			break;
		default:
			break;
		}
		//}while(true);
	}

}
