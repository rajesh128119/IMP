package com.capgemini.server;

public class Emp {
private int id;
private String name;
private double salary;
private String designation;
private String InsuranceSchema;
public final int getId() {
	return id;
}
public final void setId(int id) {
	this.id = id;
}
public final String getName() {
	return name;
}
public final void setName(String name) {
	this.name = name;
}
public final double getSalary() {
	return salary;
}
public final void setSalary(double salary) {
	this.salary = salary;
}
public final String getDesignation() {
	return designation;
}
public final void setDesignation(String designation) {
	this.designation = designation;
}
public final String getInsuranceSchema() {
	return InsuranceSchema;
}
public final void setInsuranceSchema(String insuranceSchema) {
	InsuranceSchema = insuranceSchema;
}
@Override
public String toString() {
	return "Emp [id=" + id + ", name=" + name + ", salary=" + salary
			+ ", designation=" + designation + ", InsuranceSchema="
			+ InsuranceSchema + "]";
}
public Emp(int id, String name, double salary, String designation,
		String insuranceSchema) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
	InsuranceSchema = insuranceSchema;
}
//public Emp() {
//	super();
//	// TODO Auto-generated constructor stub
//}


}
