package com.capgemini;

import java.util.Scanner;

import com.capgemini.exception.UDException;

public class PersonMain {
	
	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter firstName");
		String firstName = scan.nextLine();
		System.out.println("Enter lastName");
		String lastName=scan.nextLine();
		
		Person p=new Person();
		try {
			String name = p.validateName(firstName,lastName);
			System.out.println(name);
		} catch (UDException e) {
			System.out.println("User Defined Exception"+e);
		}
	scan.close();
	}
}
