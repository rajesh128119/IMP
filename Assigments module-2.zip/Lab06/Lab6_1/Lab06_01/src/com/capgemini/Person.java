package com.capgemini;

import com.capgemini.exception.UDException;

public class Person {

	private String firstName = null;
	private String lastName = null;
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ "]";
	}
	public String validateName(String firstName2, String lastName2) throws UDException {
		
		if((firstName2.equals(""))&&(lastName2.equals(""))){
			throw new UDException("Enter valid Name..");
		}else{
			return firstName2+lastName2;
		}
		
	}
	
}
