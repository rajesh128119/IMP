package com.capgemini.exception;

public class UDException extends Exception {

	public UDException(String msg) {
		super(msg);

	}

}
