package com.capgemini.exception;

public class UserDefinedException extends Exception {

	public UserDefinedException(String msg) {
		super(msg);
	}

}
