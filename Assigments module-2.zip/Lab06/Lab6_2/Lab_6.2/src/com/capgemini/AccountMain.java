package com.capgemini;

import java.util.Scanner;

import com.capgemini.exception.UserDefinedException;

public class AccountMain {
	public static void main(String[] args) {
		Account acc1=new Account();
		Scanner scan = new Scanner(System.in);
		String name=null;
		float age=0;
		System.out.println("Enter user Name:");
		name = scan.nextLine();
		System.out.println("Enter age");
		age = scan.nextInt();
		 try {
			acc1.validateAge(age);
			 int num=acc1.autoGenerate();
			 acc1 = new Account(num, 3000, name, age);
			 System.out.println(acc1);
		} catch (UserDefinedException e) {
			System.out.println("User Defined Exception"+e);	
		}
		
		 
	}
}
