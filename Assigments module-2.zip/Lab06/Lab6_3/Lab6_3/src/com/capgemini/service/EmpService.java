package com.capgemini.service;

import com.capgemini.server.Emp;

public interface EmpService {

	boolean Validatename(String name);



	String setinsurance(double salary, String designation);



	void ValidateSalary(double salary) throws Exception;





}
