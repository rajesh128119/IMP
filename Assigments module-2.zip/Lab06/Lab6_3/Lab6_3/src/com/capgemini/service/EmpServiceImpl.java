package com.capgemini.service;



import com.capgemini.exception.Message;

public class EmpServiceImpl implements EmpService {


	public EmpServiceImpl() {

	}

	@Override
	public boolean Validatename(String name) {
		return name.matches("[A-Z][A-Za-z]*") ;
	}



	@Override
	public String setinsurance(double salary, String designation) {
	String insuranceScheme=null;
	if((salary<5000)||(designation.equalsIgnoreCase("Clerk")))
	{
		insuranceScheme="No Scheme";
	}
	else
		if((salary>=40000)||(designation.equalsIgnoreCase("Manager")))
		{
			insuranceScheme="Scheme A";
		}
		else
			if(((salary>=20000)&&(salary<40000))||((designation.equalsIgnoreCase("Programmer"))))
			{
				insuranceScheme="Scheme B";
			}
			else
				if(((salary>=5000)&&(salary<20000))||((designation.equalsIgnoreCase("System Associate"))))
				{
					insuranceScheme="Scheme C";
				}
			
		return insuranceScheme;
	}

	@Override
	public void ValidateSalary(double salary) throws Exception {
	 if(salary<3000)
	 {
		 throw new Exception(Message.SALARY_LESS_THAN_3000);
	 }
	}

}
