package com.capgemini.exception;

public class Message {

	public static final String SALARY_LESS_THAN_3000 = "Salary should not be less than 3000";
	
	
	
}
