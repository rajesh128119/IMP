package com.capgemini;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.server.Emp;
import com.capgemini.service.EmpService;
import com.capgemini.service.EmpServiceImpl;

public class Client {
	static Emp emp = null;
	static Scanner scan = new Scanner(System.in);
    static EmpService eSerivce = new EmpServiceImpl();
	public static void main(String[] args) {
		do{
		System.out.println("Choose option from below");
		System.out.println("1. Save Employee");
		System.out.println("2. Insurance Scheme for employee");
		System.out.println("3. Display Details of Employee");
		System.out.println("4. Exit");
		String choice=scan.nextLine();
		executeCase(choice);
		}while(true);
	}
	private static void executeCase(String choice) {

	  switch(choice)
	  {
	  case "1" : 
		  		System.out.println("To save the details of the employee");
		  		System.out.println("Enter the id of the Employee");
		  		int id =0;
		  		do{
		  			try{
		  				id=scan.nextInt();
				  		break;	
		  			}catch(InputMismatchException e)
		  			{
		  				System.out.println("Please enter the id in numbers only");
		  			}
		  					  				  					
		  		}while(true);
		  		
		  	boolean nameValid=false;
		  	String name=null;
		  	System.out.println("Enter the name");
		  	while(!nameValid)
		  	{
		  		name = scan.nextLine();
		  		nameValid=eSerivce.Validatename(name);
		  		if(!nameValid)
		  		{
		  			System.out.println("Please enter the name Starting with First Caps");
		  		}
		  	}
		
		  	System.out.println("Enter the Salary of the Employee");
		   	double salary = scan.nextDouble();
		try {
			eSerivce.ValidateSalary(salary);
		} catch (Exception e1) {
			System.out.println(e1);
			
		}	
		  	System.out.println("Enter the Designation of the Employee");
		  	String designation = scan.next();
		  	String insuranceScheme=eSerivce.setinsurance(salary,designation);
		  	emp = new Emp(id,name,salary,designation,insuranceScheme);
		  	System.out.println(emp);
		  	break;
	  
	  case "2" : System.out.println("Enter the salary or designation");
	  			 String value= scan.nextLine();
	  			 String scheme = null;
	  			 try
	  			 {
	  				 int value1 = Integer.parseInt(value);
	  				 scheme = eSerivce.setinsurance(value1, "");
	  				 System.out.println(scheme);
	  			 }catch (NumberFormatException e) {
	  				System.out.println(value);
	  				scheme = eSerivce.setinsurance(0, value);
	  				System.out.println(scheme);
								}
	  			 break;
	  			 
	  case "3" :
		  if(emp!=null)	
	  
		  System.out.println("The details of the emp are"+emp);
	 
		  else
		  
			  System.out.println("Sorry the record of the employee could not be found");
		  
	  
	  	break;
	  
	  case "4":
	  	System.out.println("thanks u for using the application");
	   System.exit(0);
	   break;
	   default:
	   
	  }
		
	}

}
