package com.cg.eis.pl;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeSet;




import org.apache.log4j.Logger;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.ExceptionCheck;
import com.cg.eis.exception.LessSalaryException;
import com.cg.eis.service.EmpService;
import com.cg.eis.service.EmpServiceImpl;

public class Client {
	static Scanner scan;
	static Employee emp;
	static EmpServiceImpl eService = new EmpService();
	static Logger logger = Logger.getLogger(Client.class);
	public static void main(String[] args) {
		scan = new Scanner(System.in);
		do {
			System.out.println("\n\n1.Get Employee details from user");
			System.out
					.println("2.Find the Insurance scheme for an employee based on salary and designation.");
			System.out.println("3.Display all the details of an employee from file");
			System.out.println("4.Delete an employee");
			System.out.println("5.Sorted Employee List based on salary");
			System.out.println("6.Enter Insurance Scheme to get employee details");
			System.out.println("7.Exit");
			String choice = scan.next();
			executeCase(choice);
		} while (true);

	}

	private static void executeCase(String choice) {
		int id = 0;
		String name = null;
		String designation = null;
		double salary;
		HashMap savedEmp;
		switch (choice) {
		case "1":
			System.out.println("Enter employee Id");
			do {
				try {
					id = scan.nextInt();
					break;
				} catch (InputMismatchException e) {
					System.out.println("Enter number only");
					scan.nextLine();
				}
			} while (true);
			boolean nameValid = false;
			System.out
					.println("Name should start with uppercase and have alphabets only..");
			while (!nameValid) {
				name = scan.next();
				nameValid = eService.validateName(name);
			}
			System.out.println("Enter Salary:");
			salary = scan.nextDouble();
			try {
				eService.validSalary(salary);
				System.out.println("Enter designation");
				designation = scan.next();
				String InsuranceSchema = eService.assignScheme(salary,
						designation);
				emp = new Employee(id, name, salary, designation,
						InsuranceSchema);
				eService.addEmployee(emp);
				logger.info("Employee saved"+emp);
			} catch (LessSalaryException e1) {
				System.out.println("Less Salary Exception" + e1);
				logger.error("Employee less salary"+emp);

			}

			break;
		case "2":
			System.out.println("Enter salary or designation..");
			String value = scan.next();
			String scheme = null;
			try {
				int value1 = Integer.parseInt(value);
				scheme = eService.assignScheme(value1, "");
				System.out.println(scheme);
				logger.info("assigned scheme based on salary"+scheme);
			} catch (NumberFormatException e) {
				System.out.println(value);
				scheme = eService.assignScheme(0, value);
				System.out.println(scheme);
				logger.error("assigned scheme based on designation"+scheme);
				
			}

			break;
		case "3":
			//using file reader
			try {
				emp = eService.showEmployeeUsingFile();
			} catch (ExceptionCheck e) {
				System.out.println("File:"+e);
			}
//			System.out.println(emp);
			//savedEmp = eService.showEmployee();
			//System.out.println(savedEmp);
			break;
		case "4":
			System.out.println("Enter employee ID to delete..");
			int empid = scan.nextInt();
			boolean delete = eService.deleteEmployee(empid);
			System.out.println(delete);
			break;
		case "5":
			TreeSet savedTree = eService.sortedEmp();
			System.out.println(savedTree);

			break;
		case "6":System.out.println("Enter insurance scheme");
				String insurance = scan.next();
			//	eService.getEmployeeDetails(insurance);
			break;
		case "7":
			System.out.println("Thanks for using app..");
			System.exit(0);
			break;
		default:
			break;
		}

	}

}
