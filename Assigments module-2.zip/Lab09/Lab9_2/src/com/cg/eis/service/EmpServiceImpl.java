package com.cg.eis.service;

import java.util.HashMap;
import java.util.TreeSet;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.ExceptionCheck;
import com.cg.eis.exception.LessSalaryException;



public interface EmpServiceImpl {

	String assignScheme(double salary, String designation);

	boolean validateName(String name);

	void validSalary(double salary) throws LessSalaryException;

	void addEmployee(Employee emp);

	HashMap showEmployee();

	boolean deleteEmployee(int empid);

	TreeSet sortedEmp();


	Employee showEmployeeUsingFile() throws ExceptionCheck;








}
