package com.cg.eis.service;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.ExceptionCheck;

public class EmpServiceJUnitTest {
	HashMap<Integer, Employee> map = new HashMap();
	Employee emp= new Employee(12,"Kajal",12000,"Programmer","Scheme C");
	String file = "emp.txt";
	EmpService eService;
	
	@Before
	public void setUp() throws Exception {
	eService =   new EmpService();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddEmployee() {
		
		map.put(emp.getId(),emp);
		System.out.println(map);
		assertTrue(map.size()>0);


	}
	@Test//(expected=ExceptionCheck.class)
	public void testShowEmployeeUsingFile() throws ExceptionCheck {
	
		Employee emp = eService.showEmployeeUsingFile(); 
		assertNotNull(emp);
		
	}

}
