package com.cg.eis.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.ExceptionCheck;
import com.cg.eis.exception.LessSalaryException;


public class EmpService implements EmpServiceImpl {
	
	 HashMap<Integer,Employee> savedEmp = new HashMap();
	 Employee emp = null;
		
	@Override
	public String assignScheme(double salary, String designation) {
		String scheme =null;
		if((salary>5000 &&salary<20000)||(designation.equalsIgnoreCase("System Associate"))){
			scheme="Scheme C";
		}else if((salary>=20000 && salary<40000)||(designation.equalsIgnoreCase("Programmer"))){
			scheme="Scheme B";
		}else if(salary>=40000||designation.equalsIgnoreCase("Manager")){
			scheme="Scheme A";
		}else{
			scheme="No Scheme";
		}
		return scheme;
	}

	@Override
	public boolean validateName(String name) {
		
		return name.matches("[A-Z][a-zA-Z]*");
	}

	@Override
	public void validSalary(double salary) throws LessSalaryException {
		if(salary<3000)
			throw new LessSalaryException("Salary should be more than 3000");
		
	}
	
	@Override
	public void addEmployee(Employee emp) {
		
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter("Employee.txt",true));
			
			bw.write(emp.getId()+","+emp.getName()+","+emp.getSalary()+","
					+emp.getDesignation()+","+emp.getInsuranceScheme());
			bw.newLine();
			bw.flush();
			
		} catch (IOException e) {
		
		}
		
		
		
	}

	@Override
	public HashMap showEmployee() {
		return savedEmp;
		
	}

	@Override
	public boolean deleteEmployee(int empid) {
		boolean delete =false;
		if(savedEmp.size()>0){
			savedEmp.remove(empid);
			delete = true;
		}
		return delete;
		
	}

	@Override
	public TreeSet sortedEmp() {
		TreeSet t= new TreeSet();
		 Set<Integer> keys = savedEmp.keySet();
		 for (Integer id : keys) {
			 t.add(savedEmp.get(id));
		}
		//System.out.println(t);
	
		return t;
	}

	

	@Override
	public Employee showEmployeeUsingFile() throws ExceptionCheck {
		
		BufferedReader br ;
		try {
			br = new BufferedReader(new FileReader("Employee.txt"));
			String line = null;
			while((line = br.readLine())!=null){
				String [] values = line.split(",");
				emp = new Employee(Integer.parseInt(values[0]),values[1],
						Double.parseDouble(values[2]),values[3],values[4]);
				System.out.println(emp);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new ExceptionCheck("File Not Found");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return emp;
		
	}






}
