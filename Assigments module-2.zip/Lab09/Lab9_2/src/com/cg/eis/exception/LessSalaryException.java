package com.cg.eis.exception;

@SuppressWarnings("serial")
public class LessSalaryException extends Exception {

	public LessSalaryException(String string) {
		super(string);
	}

}
