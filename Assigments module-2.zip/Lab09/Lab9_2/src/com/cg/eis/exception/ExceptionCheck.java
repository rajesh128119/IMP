package com.cg.eis.exception;

public class ExceptionCheck extends Exception {

	public ExceptionCheck(String msg) {
		super(msg);
	}

}
