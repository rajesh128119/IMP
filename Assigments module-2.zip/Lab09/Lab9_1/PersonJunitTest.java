package com.capgemini;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PersonJunitTest {
	Person person = new Person("kajal","Srivastava");
	@Before
	public void setUp() throws Exception {
	System.out.println("Before Test");
	}

	@After
	public void tearDown() throws Exception {
	System.out.println("After Test");
	}

	@Test
	public void testGetFirstName() {
		String firstName = null;
		firstName = person.getFirstName();
		assertEquals("kajal",firstName);
		System.out.println(firstName);
		//return firstName;
	
	}
	@Test
	public void testSetFirstName(){
		String firstName="Nisha";
		person.setFirstName(firstName);
		assertEquals("Nisha", person.getFirstName());
	}

}
