package com.capgemini.util;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;



public class DBUtil {
Connection conn=null;
OracleDataSource ods =null;
public DBUtil() {
	try {
		ods = new OracleDataSource();
		ods.setURL("jdbc:oracle:thin:@localhost:1521:XE");
		ods.setUser("system");
		ods.setPassword("sys");
		ods.setDriverType("thin");
		ods.setNetworkProtocol("tcp");
	} catch (SQLException e) {
		
	}
	

}
	public Connection getConnection() {
		try {
			if(conn==null||conn.isClosed())
			conn = ods.getConnection();
		} catch (SQLException e) {
		
		}
		return conn;
	}

}
