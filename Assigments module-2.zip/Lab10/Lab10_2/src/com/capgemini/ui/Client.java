package com.capgemini.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.exception.LessSalaryException;
import com.capgemini.exception.UserSQLException;
import com.capgemini.service.EmpService;
import com.capgemini.service.EmpServiceImpl;
import com.capgemini.to.Employee;

public class Client {
	static Scanner scan = new Scanner(System.in);
	static EmpService eService = new EmpServiceImpl();
	static Employee emp = null;

	public static void main(String[] args) {

		do {
			System.out.println("1.Enter Employee Details");
			System.out.println("2.Display Employee Details");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			String choice = scan.next();
			executeCase(choice);
		} while (true);
	}

	private static void executeCase(String choice) {
		int id = 0;

		switch (choice) {
		case "1":
			System.out.println("Enter employee Id");
			do {
				try {
					id = scan.nextInt();
					break;
				} catch (InputMismatchException e) {
					System.out.println("Enter number only");
					scan.nextLine();
				}
			} while (true);
			boolean valid = false;
			String name = null;
			while (!valid) {
				System.out.println("Enter name");
				name = scan.next();
				valid = eService.validateName(name);
			}
			System.out.println("Enter Salary:");
			double salary = scan.nextDouble();
			try {
				eService.validSalary(salary);
			} catch (LessSalaryException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("Enter designation");
			String designation = scan.next();
			String InsuranceSchema = eService.assignScheme(salary, designation);
			emp = new Employee(id, name, salary, designation, InsuranceSchema);
			boolean validEmp = false;
			try {
				validEmp = eService.addEmployee(emp);
				System.out.println("Emp saved");
			} catch (UserSQLException e) {
				System.out.println("SqlException" + e);
			}
			break;

		case "2":List<Employee> list=new ArrayList<Employee>();
			System.out.println("Display employee");
			try {
				list=eService.displayEmployee();
				System.out.println(list);
			} catch (UserSQLException e) {
				System.out.println("SqlException"+e);
			}
			break;
		case "3":
			System.exit(0);

		default:
			System.out.println("Enter Selected item");
			break;
		}

	}
}
