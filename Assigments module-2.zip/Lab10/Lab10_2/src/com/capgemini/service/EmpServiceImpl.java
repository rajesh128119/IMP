package com.capgemini.service;

import java.util.List;
import java.util.Properties;

import com.capgemini.dao.EmpDao;
import com.capgemini.dao.EmpDaoImpl;
import com.capgemini.exception.LessSalaryException;
import com.capgemini.exception.UserSQLException;
import com.capgemini.to.Employee;
import com.capgemini.util.Config;






public class EmpServiceImpl implements EmpService {

	EmpDao eDao ;
	Config config;
	
public EmpServiceImpl() {
		
		config = new Config();
		Properties prop = config.getProps();
		String choice =(String) prop.get("CHOICE");
		if(choice.equals("DATABASE"))
			eDao = new EmpDaoImpl();
	}

	@Override
	public boolean validateName(String name) {

		
		return name.matches("[A-Z][a-zA-Z]*");
	}

	@Override
	public void validSalary(double salary) throws LessSalaryException {
		if(salary<3000)
			throw new LessSalaryException("Salary should be more than 3000");
		
	}

	@Override
	public String assignScheme(double salary, String designation) {
		String scheme =null;
		if((salary>5000 &&salary<20000)||(designation.equalsIgnoreCase("System Associate"))){
			scheme="Scheme C";
		}else if((salary>=20000 && salary<40000)||(designation.equalsIgnoreCase("Programmer"))){
			scheme="Scheme B";
		}else if(salary>=40000||designation.equalsIgnoreCase("Manager")){
			scheme="Scheme A";
		}else{
			scheme="No Scheme";
		}
		return scheme;
	}

	@Override
	public boolean addEmployee(Employee emp) throws UserSQLException {
	
		return eDao.addEmployee(emp);
	}

	@Override
	public List<Employee> displayEmployee() throws UserSQLException {
		return eDao.displayEmployee();
		
	}


}
