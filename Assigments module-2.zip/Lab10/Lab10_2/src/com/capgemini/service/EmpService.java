package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.LessSalaryException;
import com.capgemini.exception.UserSQLException;
import com.capgemini.to.Employee;


public interface EmpService {

	boolean validateName(String name);

	void validSalary(double salary) throws LessSalaryException;

	String assignScheme(double salary, String designation);

	boolean addEmployee(Employee emp) throws UserSQLException;

	List<Employee> displayEmployee() throws UserSQLException;

	


}
