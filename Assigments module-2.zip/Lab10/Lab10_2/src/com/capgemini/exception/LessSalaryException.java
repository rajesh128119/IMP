package com.capgemini.exception;

public class LessSalaryException extends Exception {

	public LessSalaryException(String msg) {
		super(msg);
	}

}
