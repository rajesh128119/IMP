package com.capgemini.exception;

public class UserSQLException extends Exception {

	public UserSQLException(String msg) {
		super(msg);
	}

}
