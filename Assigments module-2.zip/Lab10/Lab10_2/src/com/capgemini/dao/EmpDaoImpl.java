package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.exception.UserSQLException;
import com.capgemini.to.Employee;
import com.capgemini.util.DBUtil;


public class EmpDaoImpl implements EmpDao {

	
	Connection conn=null;
	DBUtil dUtil = new DBUtil();
	PreparedStatement ps;
	Employee emp;
	String insertQuery="insert into employee1(id,name,salary,designation,insurancescheme) values(?,?,?,?,?)";
	String showQuery ="select id,name,salary,designation,insurancescheme from employee1";
	@Override
	public boolean addEmployee(Employee emp) throws UserSQLException {
	conn=dUtil.getConnection();
	boolean saved =false;
	try {
		conn.setAutoCommit(false);
		ps=conn.prepareStatement(insertQuery);
		ps.setInt(1, emp.getId());
		ps.setString(2, emp.getName());
		ps.setDouble(3, emp.getSalary());
		ps.setString(4, emp.getDesignation());
		ps.setString(5, emp.getInsuranceScheme());
		int rows=ps.executeUpdate();
		if(rows>0)
			saved =true;
		conn.commit();
	} catch (SQLException e) {
		try {
			conn.rollback();
		} catch (SQLException e1) {
			System.out.println("RollBack");
		}
		throw new UserSQLException("Cannot insert into database");
	}
		return saved;
	}
	@Override
	public List<Employee> displayEmployee() throws UserSQLException {
		List<Employee> list = new ArrayList<Employee>(); 
		try {
			conn = dUtil.getConnection();
			Statement stmt =conn.createStatement();
			ResultSet rs= stmt.executeQuery(showQuery);
			while(rs.next()){
				emp=new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getString(5));
				list.add(emp);
			}
			
		} catch (SQLException e) {
			throw new UserSQLException("Cannot fetch data from database");
		}
		return list;
		
	}

}
