package com.capgemini.dao;

import java.util.List;

import com.capgemini.exception.UserSQLException;
import com.capgemini.to.Employee;

public interface EmpDao {

	boolean addEmployee(Employee emp) throws UserSQLException;

	List<Employee> displayEmployee() throws UserSQLException;

}
