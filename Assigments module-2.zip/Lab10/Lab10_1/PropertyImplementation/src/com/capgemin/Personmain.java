package com.capgemin;


import java.util.Properties;

public class Personmain {
	static Config config=new Config();
	public static void main(String[] args) {
		Properties props = config.getProps();
		String choice =(String)props.get("Id");
//		System.out.println(choice);
		Person p = new Person(Integer.parseInt(choice),(String)props.get("Name"));
		System.out.println(p);
	}
		
	
}
