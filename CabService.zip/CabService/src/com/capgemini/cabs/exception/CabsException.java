package com.capgemini.cabs.exception;

public class CabsException extends Exception{

	String message;
	public CabsException(String message)
	{
		this.message=message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}
	
	
}
