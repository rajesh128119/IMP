package com.capgemini.cabs.service;

import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.exception.CabsException;

public interface ICabService {

	//Declaration of Method
	public int addCabRequestDetails(CabsRequests cabRequest) throws CabsException;
	public CabsRequests getRequestDetails(int requestId) throws CabsException;
	public boolean validation(CabsRequests input);
}
