package com.capgemini.cabs.dto;

import java.time.LocalDate;

public class CabsRequests {
			
	
	//declaration of all attribute
	private int requestId;			
	private String customerName;
	private String phoneNumber;
	private LocalDate dateOfRequest;
	private String requestStatus;
	private String cabNumber;
	private String addOfPick;
	private String pincode;
	
	
	
	public CabsRequests() 	//default constructor
	{
		super();
	}
	
	
	//Parameterized Constructor
	public CabsRequests(int requestId, String customerName, String phoneNumber,
			LocalDate dateOfRequest, String requestStatus, String cabNumber,
			String addOfPick, String pincode) 
	{
		super();
		this.requestId = requestId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.dateOfRequest = dateOfRequest;
		this.requestStatus = requestStatus;
		this.cabNumber = cabNumber;
		this.addOfPick = addOfPick;
		this.pincode = pincode;
	}
	
	
	//Getter and Setter Method implementation
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(LocalDate dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getAddOfPick() {
		return addOfPick;
	}
	public void setAddOfPick(String addOfPick) {
		this.addOfPick = addOfPick;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	//override toString method implementation
	@Override
	public String toString() {
		return "CabsRequests [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", cabNumber=" + cabNumber + ", addOfPick="
				+ addOfPick + ", pincode=" + pincode + "]";
	}

}
