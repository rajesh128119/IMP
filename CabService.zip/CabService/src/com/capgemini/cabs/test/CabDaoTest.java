package com.capgemini.cabs.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.cabs.dao.CabRequestDAO;
import com.capgemini.cabs.dao.ICabRequestDAO;
import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.exception.CabsException;
import com.capgemini.cabs.service.CabService;


public class CabDaoTest {

	CabService service;
	ICabRequestDAO dao;
	
	
	@Before
	public void init()				//Block execute before each test case
	{
		service=new CabService();
		dao=new CabRequestDAO();
		service.setDao(dao);
	}
	
	
	@Test
	public void testAddCabRequestDetails() throws CabsException {
		
		CabsRequests cabRequest= new CabsRequests();
		cabRequest.setCustomerName("Shubham");
		cabRequest.setPhoneNumber("8421765567");
		cabRequest.setAddOfPick("Capgemini, Mumbai");
		cabRequest.setPincode("411026");
		cabRequest.setDateOfRequest(LocalDate.now());
		
		assertNotNull(service.addCabRequestDetails(cabRequest));
		
	}

	@Test
	public void testGetRequestDetails() throws CabsException {
		
		assertNotNull(service.getRequestDetails(1004));
	}
	
	@After
	public void destroy()			//Block execute after each test case
	{
		service=null;
		dao=null;
	}

}
