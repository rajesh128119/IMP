package com.capgemini.cabs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import org.apache.log4j.Logger;
import com.capgemini.cabs.dbutil.DBUtil;
import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.exception.CabsException;
import com.capgemini.cabs.logger.CabsLogger;


public class CabRequestDAO implements ICabRequestDAO{
	

	Logger logger=CabsLogger.getLoggerInstance();	//Creating Logger Class instance
	
	Connection con;
	
	 public CabRequestDAO() {
		
		 con=DBUtil.getConnection();			//getting connection with database
		 if(con!=null)
			{
				logger.info("Obtained Connection");
			}
	}
	
	 
	@Override
	public int addCabRequestDetails(CabsRequests cabRequest) throws CabsException {

		int bookid=0;
		boolean flag=false;
		PreparedStatement pstmt;
		
		//Hashtable to store Pin Code And Cab Number
		Hashtable<String, String> table=new Hashtable<String,String>();
		table.put("400096", "MH VS 2345");
		table.put("411026", "MH VH 34567");
		table.put("411013", "MH AN 97886");
		table.put("560066", "MH AS 875");
		table.put("382009", "MH KN 9856");
		table.put("400708", "MH TF 8956");

		String pincode=cabRequest.getPincode();
		
		//To Match Input pincode with Stored set of pincode
		for(String pin:table.keySet())
		{
			if(pincode.equals(pin))
			{
				cabRequest.setCabNumber(table.get(pin));
				cabRequest.setRequestStatus("Accepted");
				flag=true;
				break;
			}
		}
		
		if(!flag)
		{
			
			cabRequest.setRequestStatus("Not Accepted");
			cabRequest.setCabNumber(null);
			System.out.println("Pin Code does not match");
		}
		
		
		
		try
		{
			//To Insert Booking details in Database
			String sql="INSERT INTO CAB_REQUEST VALUES(seq_request_id.nextval,?,?,?,?,?,?,?)";
			 pstmt= con.prepareStatement(sql); 
			
			pstmt.setString(1, cabRequest.getCustomerName());
			pstmt.setString(2, cabRequest.getPhoneNumber());
			pstmt.setDate(3, Date.valueOf(cabRequest.getDateOfRequest()));
			pstmt.setString(4, cabRequest.getRequestStatus());
			pstmt.setString(5, cabRequest.getCabNumber());
			pstmt.setString(6, cabRequest.getAddOfPick());
			pstmt.setString( 7, cabRequest.getPincode());
			int row=pstmt.executeUpdate();
			if(row==0)
				throw new CabsException("Unable to Insert");
			else
			{
				
				//If Data inserted Then fetch it's Request Id
				logger.info("inserted record "+cabRequest);
				
				String idsql="SELECT seq_request_id.currval FROM DUAL";
				Statement stmt=con.createStatement();
				ResultSet result=stmt.executeQuery(idsql);
				
				if(result.next())
				{
					bookid=result.getInt(1);
				}
				else
					throw new CabsException("No booking id assign");
				
			}
			
			
		}
		
		
		catch(SQLException e)
		{
			logger.error("Exception occured"+e.getMessage());
			throw new CabsException("Exception while requesting for cab");
		}
		
		return bookid;
	}

	@Override
	public CabsRequests getRequestDetails(int requestId) throws CabsException {
		
		
		CabsRequests details=null;
		PreparedStatement pstmt;
		
		try
		{
			//To get booking details for particular request id
		String getDetail="SELECT customer_name,request_status,cab_number,address_of_pickup FROM CAB_REQUEST WHERE request_id=?";
		pstmt=con.prepareStatement(getDetail);
		pstmt.setInt(1, requestId);
		
		ResultSet result=pstmt.executeQuery();
		
		if(result.next())
		{
			details=new CabsRequests();
			details.setCustomerName(result.getString(1));
			details.setRequestStatus(result.getString(2));
			details.setCabNumber(result.getString(3));
			details.setAddOfPick(result.getString(4));
			logger.info("fetch record "+details );			//Storing fetch record in logger file
		}
		else
		{
			//To validate Request Id
			throw new CabsException("No such Request Id found");
		}
		
		
		}
		catch(SQLException e)
		{
			logger.error("Exception occured during fetching details"+e.getMessage());
			System.out.println("Exception while fetching booking details");
		}
		return details;
	}

}
